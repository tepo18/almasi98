import re
import subprocess
import json
import os
import urllib.parse
from rich import print
from rich.table import Table

# ------------------ مسیر ثابت ذخیره ------------------
OUTPUT_FOLDER = "/storage/emulated/0/Download/almasi98"
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

PROTOCOLS = ["vless://", "vmess://", "trojan://", "ss://"]

# ------------------ هسته ورودی و پینگ ------------------
def get_input():
    """دریافت لینک‌ها از کاربر"""
    print("[bold cyan]Paste your configs (Ctrl+D to finish):[/bold cyan]")
    lines = []
    while True:
        try:
            line = input().strip()
            if line:
                lines.append(line)
        except EOFError:
            break
    return lines

def extract_host(config):
    match = re.search(r"@([^:/?#]+)", config)
    return match.group(1) if match else None

def ping_host(host):
    try:
        output = subprocess.check_output(
            ["ping", "-c", "3", "-W", "1", host],
            stderr=subprocess.DEVNULL
        ).decode()
        match = re.search(r"rtt min/avg/max/mdev = [\d.]+/([\d.]+)", output)
        return float(match.group(1)) if match else None
    except:
        return None

def classify_ping(ping):
    if ping is None or ping < 1:
        return "red", "[bold red][BAD][/bold red]"
    elif ping <= 1500:
        return "green", "[bold green][GOOD][/bold green]"
    else:
        return "yellow", "[bold yellow][WARN][/bold yellow]"

def process_configs(lines):
    """پینگ لینک‌ها و دسته‌بندی آنها"""
    total_raw = len(lines)
    green, yellow, red = [], [], []
    valid_configs = []

    for line in lines:
        if not any(line.startswith(p) for p in PROTOCOLS):
            continue
        host = extract_host(line)
        if not host:
            print(f"[red][INVALID][/red] {line}")
            continue
        ping = ping_host(host)
        status, label = classify_ping(ping)
        print(f"{label} {host} - {ping if ping else 'NO REPLY'}ms")
        if status in ["green", "yellow"]:
            valid_configs.append(line)
            if status=="green": green.append(line)
            else: yellow.append(line)
        else:
            red.append(line)

    table = Table(title="Ping & Config Summary")
    table.add_column("Metric")
    table.add_column("Value")
    table.add_row("Total input", str(total_raw))
    table.add_row("Valid (Green+Yellow)", str(len(valid_configs)))
    table.add_row("Green ping", str(len(green)))
    table.add_row("Yellow ping", str(len(yellow)))
    table.add_row("Red ping / Bad", str(len(red)))
    print(table)

    return valid_configs

# ------------------ parse لینک ------------------
def parse_vless_link(link):
    """تبدیل لینک VLESS به دیکشنری"""
    try:
        main = link.split("://", 1)[1]
        remark = ""
        if "#" in main:
            main, remark = main.split("#", 1)
            remark = urllib.parse.unquote(remark)
        if "?" in main:
            addr_port, params = main.split("?", 1)
            query = urllib.parse.parse_qs(params)
        else:
            addr_port = main
            query = {}
        if "@" in addr_port:
            user_id, host_port = addr_port.split("@", 1)
        else:
            user_id = ""
            host_port = addr_port
        if ":" in host_port:
            address, port = host_port.split(":", 1)
        else:
            address = host_port
            port = 443
        return {
            "protocol":"vless",
            "address":address,
            "port":int(port),
            "id":user_id,
            "params":{k:v[0] for k,v in query.items()},
            "remark":remark or link
        }
    except:
        return None

# ------------------ Fragment 1 ------------------
def fragment_v1(configs):
    fragments = []
    for i, cfg in enumerate(configs):
        outbound = {
            "tag":"proxy","protocol":"vless",
            "settings":{"vnext":[{"address":cfg["address"],"port":cfg["port"],"users":[{"id":cfg["id"],"encryption":cfg["params"].get("encryption","none"),"flow":cfg["params"].get("flow","")}]}]},
            "streamSettings":{"network":cfg["params"].get("type","ws"),"security":cfg["params"].get("security","tls"),
                              "sockopt":{"dialerProxy":"fragment"},
                              "tlsSettings":{"serverName":cfg["params"].get("sni",cfg["params"].get("host",cfg["address"])),"fingerprint":cfg["params"].get("fp","chrome"),"alpn":cfg["params"].get("alpn",["http/1.1"])},
                              "wsSettings":{"path":cfg["params"].get("path","/"),"headers":{"Host":cfg["params"].get("host",cfg["address"])}}}}
        fragment={"remarks":cfg["remark"] or f"💦 {i+1} - VLESS","log":{"loglevel":"warning"},
                  "dns":{"servers":[{"address":"https://8.8.8.8/dns-query","tag":"remote-dns"},{"address":"8.8.8.8","domains":[f"full:{cfg['address']}"],"skipFallback":True}],
                         "queryStrategy":"UseIP","tag":"dns"},
                  "inbounds":[{"port":10808,"protocol":"socks","settings":{"auth":"noauth","udp":True,"userLevel":8},
                               "sniffing":{"destOverride":["http","tls"],"enabled":True,"routeOnly":True},"tag":"socks-in"},
                              {"port":10853,"protocol":"dokodemo-door","settings":{"address":"1.1.1.1","network":"tcp,udp","port":53},"tag":"dns-in"}],
                  "outbounds":[outbound,{"tag":"fragment","protocol":"freedom",
                                          "settings":{"fragment":{"packets":"tlshello","length":"100-200","interval":"1-1"},"domainStrategy":"UseIPv4v6"}}],
                  "routing":{"domainStrategy":"IPIfNonMatch","rules":[{"inboundTag":["dns-in"],"outboundTag":"dns-out","type":"field"},{"network":"tcp","outboundTag":"proxy","type":"field"}]}}
        fragments.append(fragment)
    return fragments

# ------------------ Fragment 2 ------------------
def fragment_v2(configs):
    fragments = []
    for i, cfg in enumerate(configs):
        outbound = {"tag":"proxy2","protocol":"trojan",
                    "settings":{"servers":[{"address":cfg["address"],"port":cfg["port"],"password":cfg["id"],"flow":cfg["params"].get("flow","")}]},
                    "streamSettings":{"network":cfg["params"].get("type","tcp"),"security":cfg["params"].get("security","tls"),
                                      "sockopt":{"dialerProxy":"fragment"},
                                      "tlsSettings":{"serverName":cfg["params"].get("sni",cfg["address"]),"alpn":cfg["params"].get("alpn",["h2","http/1.1"])}}}
        fragment={"remarks":cfg["remark"] or f"💧 {i+1} - TROJAN","log":{"loglevel":"warning"},
                  "inbounds":[{"port":10809,"protocol":"socks","settings":{"auth":"noauth","udp":True,"userLevel":8},"tag":"socks-in"}],
                  "outbounds":[outbound,{"tag":"fragment","protocol":"freedom",
                                          "settings":{"fragment":{"packets":"tlshello","length":"150-250","interval":"1-2"},"domainStrategy":"UseIPv4v6"}}],
                  "routing":{"domainStrategy":"IPIfNonMatch","rules":[{"inboundTag":["socks-in"],"outboundTag":"proxy2","type":"field"}]}}
        fragments.append(fragment)
    return fragments

# ------------------ Fragment 3 ------------------
def fragment_v3(configs):
    fragments = []
    for i, cfg in enumerate(configs):
        outbound = {"tag":"proxy3","protocol":"shadowsocks",
                    "settings":{"servers":[{"address":cfg["address"],"port":cfg["port"],"method":cfg["params"].get("method","aes-128-gcm"),"password":cfg["id"]}]},
                    "streamSettings":{"network":"tcp","security":"none","sockopt":{"dialerProxy":"fragment"}}}
        fragment={"remarks":cfg["remark"] or f"⚡ {i+1} - SS","log":{"loglevel":"warning"},
                  "inbounds":[{"port":10810,"protocol":"socks","settings":{"auth":"noauth","udp":True,"userLevel":8},"tag":"socks-in"}],
                  "outbounds":[outbound,{"tag":"fragment","protocol":"freedom",
                                          "settings":{"fragment":{"packets":"tlshello","length":"100-200","interval":"1-1"}}}],
                  "routing":{"domainStrategy":"IPIfNonMatch","rules":[{"inboundTag":["socks-in"],"outboundTag":"proxy3","type":"field"}]}}
        fragments.append(fragment)
    return fragments

# ------------------ تابع ذخیره خروجی ------------------
def save_fragment(fragment, default_name="fragment"):
    fname = input(f"Enter output filename (default: {default_name}.txt): ").strip() or default_name
    outpath = os.path.join(OUTPUT_FOLDER, fname + ".txt")
    with open(outpath, "w", encoding="utf-8") as f:
        json.dump(fragment, f, ensure_ascii=False, indent=2)
    print(f"[green]✅ Saved {len(fragment)} items to {outpath}[/green]")

# ------------------ منوی حلقه خروجی ------------------
def menu_loop(valid_configs):
    fragments_dict = {
        "1": ("Fragment V1", fragment_v1),
        "2": ("Fragment V2", fragment_v2),
        "3": ("Fragment V3", fragment_v3)
    }
    while True:
        print("\n[bold cyan]Select fragment to generate:[/bold cyan]")
        for k, v in fragments_dict.items():
            print(f"{k}. {v[0]}")
        print("0. Exit")
        choice = input("Enter choice: ").strip()
        if choice=="0": break
        if choice in fragments_dict:
            name, func = fragments_dict[choice]
            output = func(valid_configs)
            save_fragment(output, default_name=name)
        else:
            print("[red]Invalid choice[/red]")

# ------------------ MAIN ------------------
if __name__ == "__main__":
    lines = get_input()
    valid_configs = process_configs(lines)
    parsed_list = [parse_vless_link(cfg) for cfg in valid_configs if parse_vless_link(cfg)]
    menu_loop(parsed_list)
