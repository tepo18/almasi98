
name: ch

on:
  push:
    branches:
      - main
  workflow_dispatch:
  schedule:
    - cron: '0 */8 * * *' # هر 8 ساعت اجرا می‌شود

permissions:
  contents: write # مجوز نوشتن برای پوش کردن لازم است

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout code
        uses: actions/checkout@v4
        # مهم: توکن پیش‌فرض معمولاً کافیه، ولی گاهی برای پوش به شاخه‌های محافظت‌شده
        # یا تنظیمات خاص، نیاز به personal access token (PAT) هست.
        # فعلاً با توکن پیش‌فرض کار می‌کنیم.

      - name: Configure Git Credentials
        run: |
          git config user.name github-actions[bot]
          git config user.email 41898282+github-actions[bot]@users.noreply.github.com

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: 3.x # بهتر است نسخه دقیق‌تری مثل '3.11' مشخص کنید

      # Cache steps (اختیاری ولی خوب)
      - name: Set weekly cache key
        run: echo "cache_id=$(date --utc '+%V')" >> $GITHUB_ENV

      - name: Cache dependencies
        uses: actions/cache@v4
        with:
          key: pip-cache-${{ runner.os }}-${{ steps.setup-python.outputs.python-version }}-${{ hashFiles('**/requirements.txt') }}-${{ env.cache_id }} # کلید بهتر برای کش
          path: ~/.cache/pip
          restore-keys: |
            pip-cache-${{ runner.os }}-${{ steps.setup-python.outputs.python-version }}-

      - name: Install dependencies
        run: pip install requests psutil retrying PyYaml
        # بهتره یک فایل requirements.txt بسازید و از اون استفاده کنید:
        # run: pip install -r requirements.txt

      - name: Set execute permissions
        run: |
          chmod +x xray/xray
          chmod +x hy2/hysteria

      - name: Run checker script
        run: python cl.py

      # ----- مراحل جدید برای کامیت و پوش -----
      - name: Commit and Push changes
        run: |
          # نام فایل‌های خروجی که می‌خواهید کامیت شوند
          FILE1="final.txt"

          # بررسی اینکه آیا در *هر کدام* از فایل‌ها تغییری وجود دارد
          # git status --porcelain بدون آرگومان همه تغییرات را لیست می‌کند
          if [[ -n $(git status --porcelain $FILE1) ]]; then
            echo "Changes detected in $FILE1. Committing..."
            # --- هر دو فایل را اضافه کنید ---
            git add $FILE1
            # -------------------------------
            # پیام کامیت را کمی عمومی‌تر کنید
            git commit -m "chore: Update results ($FILE1) [skip ci]"
            git push origin HEAD:main
          else
            echo "No changes detected in $FILE1. Nothing to commit."
          fi