import re
import subprocess
import os
from rich import print
from rich.table import Table

SAVE_PATH = "/sdcard/Download/almasi98/"
PROTOCOLS = ["vless://", "vmess://", "trojan://", "ss://"]
BATCH_SIZE = 5
SPACING = 15  # خطوط فاصله بین هر بسته

# ------------------ Input ------------------
def get_input():
    print("[bold cyan]Paste your configs (Ctrl+D to finish):[/bold cyan]")
    lines = []
    while True:
        try:
            line = input().strip()
            if line:
                lines.append(line)
        except EOFError:
            break
    return lines

# ------------------ Ping Module ------------------
def extract_host(config):
    match = re.search(r"@([^:/?#]+)", config)
    return match.group(1) if match else None

def ping_host(host):
    try:
        output = subprocess.check_output(
            ["ping", "-c", "3", "-W", "1", host],
            stderr=subprocess.DEVNULL
        ).decode()
        match = re.search(r"rtt min/avg/max/mdev = [\d.]+/([\d.]+)", output)
        return float(match.group(1)) if match else None
    except:
        return None

def classify_ping(ping):
    if ping is None or ping < 1:
        return "red", "[bold red][BAD][/bold red]"
    elif ping <= 1500:
        return "green", "[bold green][GOOD][/bold green]"
    else:
        return "yellow", "[bold yellow][WARN][/bold yellow]"

# ------------------ Main Processing ------------------
def process_configs(lines):
    total_raw = len(lines)
    green, yellow, red = [], [], []
    valid_configs = []

    for line in lines:
        if not any(line.startswith(p) for p in PROTOCOLS):
            continue
        host = extract_host(line)
        if not host:
            print(f"[red][INVALID][/red] {line}")
            continue
        ping = ping_host(host)
        status, label = classify_ping(ping)
        print(f"{label} {host} - {ping if ping else 'NO REPLY'}ms")
        if status == "green":
            green.append(line)
            valid_configs.append(line)
        elif status == "yellow":
            yellow.append(line)
            valid_configs.append(line)
        else:
            red.append(line)

    # summary table
    table = Table(title="Ping & Config Summary")
    table.add_column("Metric")
    table.add_column("Value")
    table.add_row("Total input", str(total_raw))
    table.add_row("Valid (Green+Yellow)", str(len(valid_configs)))
    table.add_row("Green ping", str(len(green)))
    table.add_row("Yellow ping", str(len(yellow)))
    table.add_row("Red ping / Bad", str(len(red)))
    print(table)

    return valid_configs

# ------------------ Output ------------------
def save_configs_by_protocol(configs):
    file_name = input("Enter base filename for output: ").strip()
    if not file_name:
        file_name = "output"
    os.makedirs(SAVE_PATH, exist_ok=True)

    protocol_map = {p.split("://")[0]: [] for p in PROTOCOLS}
    for cfg in configs:
        for p in PROTOCOLS:
            if cfg.startswith(p):
                protocol_map[p.split("://")[0]].append(cfg)

    for proto, cfgs in protocol_map.items():
        if not cfgs:
            continue
        out_file = os.path.join(SAVE_PATH, f"{file_name}_{proto}.txt")
        lines_to_write = []
        for i in range(0, len(cfgs), BATCH_SIZE):
            lines_to_write.extend(cfgs[i:i+BATCH_SIZE])
            lines_to_write.extend([""] * SPACING)
        with open(out_file, "w", encoding="utf-8") as f:
            f.write("\n".join(lines_to_write))
        print(f"[green]{proto} saved: {out_file}[/green]")

# ------------------ MAIN ------------------
if __name__ == "__main__":
    lines = get_input()
    filtered_configs = process_configs(lines)
    save_configs_by_protocol(filtered_configs)