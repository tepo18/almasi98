#!/bin/bash

CYAN="\e[36m"
GREEN="\e[32m"
YELLOW="\e[33m"
RESET="\e[0m"

BASE_PATH="$HOME"
DOWNLOAD_DIR="/sdcard/Download/Akbar98"
CRED_DIR="$HOME/.git-credentials-accounts"
mkdir -p "$CRED_DIR"

# ---------------- GitHub Credential Setup ----------------
echo -e "${CYAN}Do you want to use a new GitHub account or an existing one?${RESET}"
echo "1) New account"
echo "2) Existing account"
echo -ne "${CYAN}Enter choice (1 or 2): ${RESET}"
read -r CHOICE

if [ "$CHOICE" == "1" ]; then
    # اکانت جدید
    read -p "Enter GitHub username: " GIT_USER
    read -sp "Enter GitHub token: " GIT_PASS
    echo
    ACCOUNT_NAME="$GIT_USER"
    CRED_FILE="$CRED_DIR/$ACCOUNT_NAME"
    echo "https://$GIT_USER:$GIT_PASS@github.com" > "$CRED_FILE"
    chmod 600 "$CRED_FILE"
    echo -e "${GREEN}New account saved.${RESET}"
else
    # اکانت قبلی
    echo -ne "${CYAN}Enter your existing GitHub username: ${RESET}"
    read -r ACCOUNT_NAME
    CRED_FILE="$CRED_DIR/$ACCOUNT_NAME"
    if [ ! -f "$CRED_FILE" ]; then
        echo -e "${YELLOW}Credential file not found for '$ACCOUNT_NAME'. Exiting.${RESET}"
        exit 1
    fi
    GIT_USER=$(grep "github.com" "$CRED_FILE" | cut -d':' -f2 | cut -d'@' -f1 | sed 's#//##')
    echo -e "${GREEN}Using saved credentials for '$ACCOUNT_NAME'.${RESET}"
fi

# تنظیم git برای استفاده از credential این اکانت
git config --global credential.helper "store --file=$CRED_FILE"

# ---------------- Clone or use existing repo ----------------
echo -e "${CYAN}Have you already cloned the repo?${RESET}"
echo "1) No, clone a new repo"
echo "2) Yes, repo already cloned"
echo -ne "${CYAN}Enter choice (1 or 2): ${RESET}"
read -r CLONE_CHOICE

if [ "$CLONE_CHOICE" == "1" ]; then
    echo -ne "${CYAN}Enter GitHub repo name: ${RESET}"
    read -r REPO_NAME
    REPO_PATH="$BASE_PATH/$REPO_NAME"

    if [ -d "$REPO_PATH" ]; then
        echo -e "${YELLOW}Folder '$REPO_PATH' already exists!${RESET}"
    else
        echo -e "${GREEN}Cloning repo from GitHub...${RESET}"
        git clone "https://github.com/$GIT_USER/$REPO_NAME.git" "$REPO_PATH"
        if [ $? -ne 0 ]; then
            echo -e "${YELLOW}Failed to clone repo. Exiting.${RESET}"
            exit 1
        fi
    fi

elif [ "$CLONE_CHOICE" == "2" ]; then
    echo -ne "${CYAN}Enter existing repo folder name: ${RESET}"
    read -r REPO_NAME
    REPO_PATH="$BASE_PATH/$REPO_NAME"

    if [ ! -d "$REPO_PATH" ]; then
        echo -e "${YELLOW}Folder '$REPO_PATH' not found! Exiting.${RESET}"
        exit 1
    fi
else
    echo -e "${YELLOW}Invalid choice. Exiting.${RESET}"
    exit 1
fi

cd "$REPO_PATH" || { echo -e "${YELLOW}Cannot enter repo folder. Exiting.${RESET}"; exit 1; }

# ---------------- Auto-Push Function ----------------
function auto_push() {
    echo -e "${CYAN}Running auto-push script...${RESET}"

    echo "[*] Pulling latest changes..."
    git pull origin main --rebase || { echo "[ERROR] Pull failed."; return; }

    echo "[*] Staging and committing changes..."
    git add .
    git commit -m "Auto-update outputs and scripts" 2>/dev/null || echo "[INFO] Nothing to commit."

    echo "[*] Pushing to remote..."
    git push origin main || echo "[ERROR] Push failed."

    echo "[✅] Auto-push done!"
}

# ---------------- Main Menu Loop ----------------
while true; do
    echo -e "\n${CYAN}Select an option:${RESET}"
    echo "1) Create new file"
    echo "2) Edit existing file"
    echo "3) Delete a file"
    echo "4) Commit changes"
    echo "5) Push to GitHub (with sublinks)"
    echo "6) Copy content from download folder to repo file"
    echo "7) Run checker scripts"
    echo "8) Help"
    echo "9) Exit"
    echo "10) Auto-push repo"
    echo -ne "${CYAN}Choice: ${RESET}"
    read -r CHOICE

    case $CHOICE in
        1)
            echo -ne "${CYAN}Enter new filename to create: ${RESET}"
            read -r NEWFILE
            [ -e "$NEWFILE" ] && echo -e "${YELLOW}File already exists.${RESET}" || (touch "$NEWFILE" && echo -e "${GREEN}File '$NEWFILE' created.${RESET}")
            ;;
        2)
            echo -ne "${CYAN}Enter filename to edit: ${RESET}"
            read -r EDITFILE
            [ ! -e "$EDITFILE" ] && echo -e "${YELLOW}File does not exist.${RESET}" || nano "$EDITFILE"
            ;;
        3)
            echo -ne "${CYAN}Enter filename to delete: ${RESET}"
            read -r DELFILE
            [ ! -e "$DELFILE" ] && echo -e "${YELLOW}File does not exist.${RESET}" || (rm -i "$DELFILE" && echo -e "${GREEN}File deleted.${RESET}")
            ;;
        4)
            git status
            echo -ne "${CYAN}Enter commit message (leave empty for default): ${RESET}"
            read -r MSG
            git add .
            [ -z "$MSG" ] && MSG="auto update from script"
            git commit -m "$MSG" && echo -e "${GREEN}Changes committed.${RESET}" || echo -e "${YELLOW}Nothing to commit.${RESET}"
            ;;
        5)
            echo -ne "${CYAN}Push changes to GitHub? (yes/no): ${RESET}"
            read -r PUSH_ANSWER
            if [ "$PUSH_ANSWER" == "yes" ]; then
                branch_name=$(git rev-parse --abbrev-ref HEAD 2>/dev/null)
                [ "$branch_name" = "HEAD" ] || [ -z "$branch_name" ] && branch_name="auto-push-branch" && git switch -c "$branch_name"
                git add -A
                echo -ne "${CYAN}Enter commit message (leave empty for default): ${RESET}"
                read -r MSG
                [ -z "$MSG" ] && MSG="auto update from script"
                git commit -m "$MSG" --allow-empty
                git push "https://github.com/$GIT_USER/$REPO_NAME.git" --force && echo -e "${GREEN}Pushed successfully.${RESET}" || echo -e "${YELLOW}Push failed.${RESET}"
            else
                echo "Push canceled."
            fi
            ;;
        6)
            echo -ne "${CYAN}Enter source filename inside download folder ($DOWNLOAD_DIR): ${RESET}"
            read -r SRCFILE
            SRC_PATH="$DOWNLOAD_DIR/$SRCFILE"
            [ ! -f "$SRC_PATH" ] && echo -e "${YELLOW}Source file '$SRC_PATH' not found.${RESET}" && continue
            echo -ne "${CYAN}Enter target filename inside repo folder: ${RESET}"
            read -r TARGETFILE
            cat "$SRC_PATH" > "$TARGETFILE"
            echo -e "${GREEN}Content from '$SRC_PATH' copied to '$TARGETFILE'.${RESET}"
            ;;
        7)
            echo -e "${CYAN}Select which checker to run:${RESET}"
            echo "1) chek.py (repo: sab-vip10)"
            echo "2) chek1.py (repo: sab-vip10)"
            echo "3) chek.py (repo: reza-shah1320)"
            echo -ne "${CYAN}Choice: ${RESET}"
            read -r CHEK_CHOICE

            case $CHEK_CHOICE in
                1) [ -f "./chek.py" ] && python3 ./chek.py || echo -e "${YELLOW}chek.py not found.${RESET}" ;;
                2) [ -f "./chek1.py" ] && python3 ./chek1.py || echo -e "${YELLOW}chek1.py not found.${RESET}" ;;
                3) [ -f "./chek.py" ] && python3 ./chek.py || echo -e "${YELLOW}chek.py not found.${RESET}" ;;
                *) echo -e "${YELLOW}Invalid choice!${RESET}" ;;
            esac
            ;;
        8)
            echo -e "${CYAN}Help - Main Commands:${RESET}"
            echo "1) Create a new file"
            echo "2) Edit an existing file"
            echo "3) Delete a file"
            echo "4) Commit changes"
            echo "5) Push to GitHub and generate sublinks"
            echo "6) Copy file from download folder to repo"
            echo "7) Run checker scripts"
            echo "8) Show this help menu"
            echo "9) Exit script"
            echo "10) Auto-push repo"
            ;;
        9)
            echo "Exiting."
            exit 0
            ;;
        10)
            auto_push
            ;;
        *)
            echo -e "${YELLOW}Invalid choice!${RESET}"
            ;;
    esac
done