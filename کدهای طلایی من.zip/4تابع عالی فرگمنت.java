import re
import subprocess
import json
import os
import urllib.parse
from rich import print
from rich.table import Table

# ------------------ مسیر ثابت ذخیره ------------------
OUTPUT_FOLDER = "/storage/emulated/0/Download/almasi98"
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

PROTOCOLS = ["vless://", "vmess://", "trojan://", "ss://"]

# ------------------ هسته ورودی و پینگ ------------------
def get_input():
    """دریافت لینک‌ها از کاربر"""
    print("[bold cyan]Paste your configs (Ctrl+D to finish):[/bold cyan]")
    lines = []
    while True:
        try:
            line = input().strip()
            if line:
                lines.append(line)
        except EOFError:
            break
    return lines

def extract_host(config):
    match = re.search(r"@([^:/?#]+)", config)
    return match.group(1) if match else None

def ping_host(host):
    try:
        output = subprocess.check_output(
            ["ping", "-c", "3", "-W", "1", host],
            stderr=subprocess.DEVNULL
        ).decode(errors="ignore")
        match = re.search(r"rtt min/avg/max/(?:mdev|stddev) = [\d.]+/([\d.]+)", output)
        return float(match.group(1)) if match else None
    except:
        return None

def classify_ping(ping):
    if ping is None or (isinstance(ping, (int, float)) and ping < 1):
        return "red", "[bold red][BAD][/bold red]"
    elif isinstance(ping, (int, float)) and ping <= 1500:
        return "green", "[bold green][GOOD][/bold green]"
    else:
        return "yellow", "[bold yellow][WARN][/bold yellow]"

def process_configs(lines):
    """پینگ لینک‌ها و دسته‌بندی آنها؛ بازگرداندن valid raw configs و ping_results"""
    total_raw = len(lines)
    green, yellow, red = [], [], []
    valid_configs = []
    ping_results = {}  # key = raw config string -> (status, ping float or None)

    for line in lines:
        if not any(line.startswith(p) for p in PROTOCOLS):
            continue
        host = extract_host(line)
        if not host:
            print(f"[red][INVALID][/red] {line}")
            continue
        ping = ping_host(host)
        status, label = classify_ping(ping)
        print(f"{label} {host} - {ping if ping is not None else 'NO REPLY'}ms")
        # store ping result
        ping_results[line] = (status, ping)
        if status in ["green", "yellow"]:
            valid_configs.append(line)
            if status == "green":
                green.append(line)
            else:
                yellow.append(line)
        else:
            red.append(line)

    table = Table(title="Ping & Config Summary")
    table.add_column("Metric")
    table.add_column("Value")
    table.add_row("Total input", str(total_raw))
    table.add_row("Valid (Green+Yellow)", str(len(valid_configs)))
    table.add_row("Green ping", str(len(green)))
    table.add_row("Yellow ping", str(len(yellow)))
    table.add_row("Red ping / Bad", str(len(red)))
    print(table)

    return valid_configs, ping_results

# ------------------ Parse لینک VLESS ------------------
def parse_vless_link(link):
    """تبدیل لینک VLESS به دیکشنری"""
    try:
        main = link.split("://", 1)[1]
        remark = ""
        if "#" in main:
            main, remark = main.split("#", 1)
            remark = urllib.parse.unquote(remark)
        if "?" in main:
            addr_port, params = main.split("?", 1)
            query = urllib.parse.parse_qs(params)
        else:
            addr_port = main
            query = {}
        if "@" in addr_port:
            user_id, host_port = addr_port.split("@", 1)
        else:
            user_id = ""
            host_port = addr_port
        if ":" in host_port:
            address, port = host_port.split(":", 1)
        else:
            address = host_port
            port = 443
        return {
            "protocol":"vless",
            "address":address,
            "port":int(port) if str(port).isdigit() else 443,
            "id":user_id,
            "params":{k:v[0] for k,v in query.items()},
            "remark":remark or link,
            "raw":link,
            "user":user_id
        }
    except:
        return None

# Helper: parse_link_general (سبک و حداقلی برای پشتیبانی از توابعی که نیاز دارن)
def parse_link_general(link):
    link = link.strip()
    if link.startswith("vless://"):
        parsed = parse_vless_link(link)
        return ("vless", parsed) if parsed else (None, None)
    if link.startswith("trojan://"):
        try:
            main = link.split("://", 1)[1]
            remark = ""
            if "#" in main:
                main, remark = main.split("#", 1)
                remark = urllib.parse.unquote(remark)
            user_host = main
            user = ""
            host_port = user_host
            if "@" in user_host:
                user, host_port = user_host.split("@", 1)
            addr, port = (host_port.split(":",1) + ["443"])[:2]
            return ("trojan", {"protocol":"trojan","address":addr,"port":int(port) if str(port).isdigit() else 443,"user":user,"params":{},"remark":remark,"raw":link})
        except:
            return (None, None)
    if link.startswith("ss://"):
        # سعی کنیم host:port#remark را استخراج کنیم (نسخه‌ی ساده)
        try:
            main = link.split("://",1)[1]
            remark = ""
            if "#" in main:
                main, remark = main.split("#",1)
                remark = urllib.parse.unquote(remark)
            # اگر شامل @ باشد: ...@host:port
            if "@" in main:
                _, host_port = main.rsplit("@",1)
                address, port = (host_port.split(":",1) + ["443"])[:2]
                return ("ss", {"protocol":"ss","address":address,"port":int(port) if str(port).isdigit() else 443,"id":"", "params":{},"remark":remark,"raw":link})
            else:
                return (None, None)
        except:
            return (None, None)
    # fallback
    return (None, None)

# Helper: parse_link used by one of user functions
def parse_link(link):
    return parse_link_general(link)

# ------------------ === حالا پنج تابع فرگمنت مستقل ===
# توجه: من فقط نام‌گذاری انجام دادم و محتوای هر تابع را مطابقِ چیزی که فرستادی داخل تابع گذاشتم.
# تابع‌ها مستقل‌اند و انتظار می‌رود پارامترهای ورودیِ مناسب (raw یا parsed) به آنها داده شود.

# -------- Fragment V1 (انتظار parsed dicts list) --------
def fragment_v1(configs):
    fragments = []

    for i, cfg in enumerate(configs):
        outbound = {
            "tag": "proxy",
            "protocol": "vless",
            "settings": {
                "vnext": [{
                    "address": cfg["address"],
                    "port": cfg["port"],
                    "users": [{
                        "id": cfg["id"],
                        "encryption": cfg["params"].get("encryption", "none"),
                        "flow": cfg["params"].get("flow", "")
                    }]
                }]
            },
            "streamSettings": {
                "network": cfg["params"].get("type", "ws"),
                "security": cfg["params"].get("security", "tls"),
                "sockopt": {"dialerProxy": "fragment"},
                "tlsSettings": {
                    "serverName": cfg["params"].get("sni", cfg["params"].get("host", cfg["address"])),
                    "fingerprint": cfg["params"].get("fp", "chrome"),
                    "alpn": cfg["params"].get("alpn", "").split(",") if "alpn" in cfg["params"] else ["http/1.1"]
                },
                "wsSettings": {
                    "path": cfg["params"].get("path", "/"),
                    "headers": {"Host": cfg["params"].get("host", cfg["address"])}
                }
            }
        }

        fragment = {
            "remarks": cfg.get("remark") or f"💦 {i+1} - VLESS",
            "log": {"loglevel": "warning"},
            "dns": {
                "servers": [
                    {"address": "https://8.8.8.8/dns-query", "tag": "remote-dns"},
                    {"address": "8.8.8.8", "domains": [f"full:{cfg['address']}"], "skipFallback": True}
                ],
                "queryStrategy": "UseIP",
                "tag": "dns"
            },
            "inbounds": [
                {
                    "port": 10808,
                    "protocol": "socks",
                    "settings": {"auth": "noauth", "udp": True, "userLevel": 8},
                    "sniffing": {"destOverride": ["http", "tls"], "enabled": True, "routeOnly": True},
                    "tag": "socks-in"
                },
                {
                    "port": 10853,
                    "protocol": "dokodemo-door",
                    "settings": {"address": "1.1.1.1", "network": "tcp,udp", "port": 53},
                    "tag": "dns-in"
                }
            ],
            "outbounds": [
                outbound,
                {
                    "tag": "fragment",
                    "protocol": "freedom",
                    "settings": {
                        "fragment": {"packets": "tlshello", "length": "100-200", "interval": "1-1"},
                        "domainStrategy": "UseIPv4v6"
                    }
                }
            ],
            "routing": {
                "domainStrategy": "IPIfNonMatch",
                "rules": [
                    {"inboundTag": ["dns-in"], "outboundTag": "dns-out", "type": "field"},
                    {"network": "tcp", "outboundTag": "proxy", "type": "field"}
                ]
            }
        }

        fragments.append(fragment)

    return fragments

# -------- Fragment V2 (انتظار parsed_configs list; پشتیبانی از چند پروتکل) --------
def fragment_v2(parsed_configs):
    fragments = []
    for idx, cfg in enumerate(parsed_configs, 1):
        proto = cfg.get("protocol", "vless")
        server = cfg.get("address")
        port = cfg.get("port")
        uuid = cfg.get("id", "")
        name = cfg.get("remark", f"proxy{idx}")
        tls = cfg.get("params", {}).get("security", "none") == "tls"
        network = cfg.get("params", {}).get("type", "tcp")
        password = cfg.get("params", {}).get("password", "")

        # ساخت outbound بسته به پروتکل
        outbound = None
        if proto in ["vless", "vmess"]:
            outbound = {
                "tag": "proxy",
                "protocol": proto,
                "settings": {
                    "vnext": [{"address": server, "port": port, "users": [{"id": uuid, "encryption": "none"}]}]
                },
                "streamSettings": {"network": network, "security": "tls" if tls else "none"}
            }
        elif proto == "trojan":
            outbound = {
                "tag": "proxy",
                "protocol": "trojan",
                "settings": {"servers": [{"address": server, "port": port, "password": password}]},
                "streamSettings": {"network": network, "security": "tls" if tls else "none"}
            }
        elif proto in ["ss", "shadowsocks"]:
            outbound = {
                "tag": "proxy",
                "protocol": "shadowsocks",
                "settings": {"servers": [{"address": server, "port": port, "password": password, "method": "aes-128-gcm"}]},
                "streamSettings": {"network": network, "security": "none"}
            }
        else:
            continue

        fragment = {
            "remarks": name,
            "log": {"loglevel": "warning"},
            "inbounds": [
                {"port": 10808, "protocol": "socks", "settings": {"auth": "noauth", "udp": True}, "tag": "socks-in"},
                {"port": 10853, "protocol": "dokodemo-door", "settings": {"address": "1.1.1.1", "port": 53, "network": "tcp,udp"}, "tag": "dns-in"}
            ],
            "outbounds": [
                outbound,
                {"tag": "fragment", "protocol": "freedom", "settings": {"fragment": {"packets": "tlshello","length": "100-200","interval": "1-1"}, "domainStrategy": "UseIPv4v6"}}
            ],
            "routing": {"domainStrategy": "IPIfNonMatch", "rules": [{"network": "tcp", "outboundTag": "proxy", "type": "field"}]}
        }

        fragments.append(fragment)

    return fragments

# -------- Fragment V3 (انتظار raw config strings list؛ از parse_link_general و ping_results استفاده می‌کند) --------
def fragment_v3(configs, ping_results=None):
    fragments = []

    for i, cfg in enumerate(configs):
        # تشخیص پروتکل و پارس
        proto, parsed = parse_link_general(cfg)
        if not parsed:
            host = extract_host(cfg) or "0.0.0.0"
            parsed = {
                "protocol": "vless",
                "address": host,
                "port": 443,
                "user": "user",
                "params": {},
                "remark": cfg
            }
            proto = "vless"

        # بررسی ping و status اگر موجود باشد
        ping = None
        status = None
        if ping_results:
            ping_val = ping_results.get(cfg)
            if ping_val:
                status, ping = ping_val

        ping_str = f"{ping:.2f} ms" if isinstance(ping, (int, float)) else "NO REPLY"
        remark_base = parsed.get("remark") or f"Config {i+1}"
        remark_with_ping = f"{remark_base} | {ping_str} | {status or ''}"

        address = parsed.get("address", "0.0.0.0")
        port = parsed.get("port", 443)

        # DNS block
        dns_block = {
            "servers": [
                {"address": "https://8.8.8.8/dns-query", "tag": "remote-dns"},
                {"address": "8.8.8.8", "domains": [f"full:{address}"], "skipFallback": True}
            ],
            "queryStrategy": "UseIP",
            "tag": "dns"
        }

        # Inbounds block
        inbounds_block = [
            {"port":10808,"protocol":"socks","settings":{"auth":"noauth","udp":True,"userLevel":8},
             "sniffing":{"destOverride":["http","tls"],"enabled":True,"routeOnly":True},"tag":"socks-in"},
            {"port":10853,"protocol":"dokodemo-door","settings":{"address":"1.1.1.1","network":"tcp,udp","port":53},"tag":"dns-in"}
        ]

        # Routing block
        routing_block = {
            "domainStrategy": "IPIfNonMatch",
            "rules": [
                {"inboundTag":["dns-in"],"outboundTag":"dns-out","type":"field"},
                {"network":"tcp","outboundTag":"proxy","type":"field"}
            ]
        }

        # Outbound block
        outbound = {
            "tag": "proxy",
            "protocol": proto,
            "settings": {"vnext": [{"address": address, "port": port, "users": [{"id": parsed.get("user","user"), "encryption":"none","flow":""}]}]},
            "streamSettings": {
                "network": "ws",
                "security": "tls",
                "sockopt": {"dialerProxy": "fragment"},
                "tlsSettings": {"serverName": address, "fingerprint": "chrome", "alpn": ["http/1.1"]},
                "wsSettings": {"path": "/", "headers": {"Host": address}}
            }
        }

        fragment = {
            "remarks": remark_with_ping,
            "log": {"loglevel": "warning"},
            "dns": dns_block,
            "inbounds": inbounds_block,
            "outbounds": [
                outbound,
                {"tag": "fragment", "protocol": "freedom",
                 "settings": {"fragment": {"packets": "tlshello", "length": "100-200", "interval": "1-1"},
                              "domainStrategy": "UseIPv4v6"}}
            ],
            "routing": routing_block
        }

        fragments.append(fragment)

    return fragments

# -------- Fragment V5 (انتظار parsed_configs با کلیدهای خاص) --------
def fragment_v5(parsed_configs):
    fragments = []
    for idx, cfg in enumerate(parsed_configs, 1):
        # اطلاعات اصلی
        proto = cfg.get("type", "vless")
        server = cfg.get("server")
        port = cfg.get("port")
        uuid = cfg.get("uuid", "")
        name = cfg.get("name", f"proxy{idx}")
        tls = cfg.get("tls", False)
        network = cfg.get("network", "tcp")
        password = cfg.get("password", "")

        # ساخت outbounds بسته به پروتکل
        outbound = None
        if proto in ["vless", "vmess"]:
            outbound = {
                "tag": "proxy",
                "protocol": proto,
                "settings": {
                    "vnext": [{"address": server, "port": port, "users": [{"id": uuid, "encryption": "none"}]}]
                },
                "streamSettings": {"network": network, "security": "tls" if tls else "none"}
            }
        elif proto == "trojan":
            outbound = {
                "tag": "proxy",
                "protocol": "trojan",
                "settings": {"servers": [{"address": server, "port": port, "password": password}]},
                "streamSettings": {"network": network, "security": "tls" if tls else "none"}
            }
        elif proto in ["ss", "shadowsocks"]:
            outbound = {
                "tag": "proxy",
                "protocol": "shadowsocks",
                "settings": {"servers": [{"address": server, "port": port, "password": password, "method": "aes-128-gcm"}]},
                "streamSettings": {"network": network, "security": "none"}
            }
        else:
            continue  # پروتکل ناشناخته نادیده گرفته شود

        fragment = {
            "remarks": name,
            "log": {"loglevel": "warning"},
            "inbounds": [
                {"port": 10808, "protocol": "socks", "settings": {"auth": "noauth", "udp": True}, "tag": "socks-in"},
                {"port": 10853, "protocol": "dokodemo-door", "settings": {"address": "1.1.1.1", "port": 53, "network": "tcp,udp"}, "tag": "dns-in"}
            ],
            "outbounds": [
                outbound,
                {"tag": "fragment", "protocol": "freedom", "settings": {"fragment": {"packets": "tlshello","length": "100-200","interval": "1-1"}, "domainStrategy": "UseIPv4v6"}}
            ],
            "routing": {"domainStrategy": "IPIfNonMatch", "rules": [{"network": "tcp", "outboundTag": "proxy", "type": "field"}]}
        }

        fragments.append(fragment)

    return fragments

# ------------------ تابع ذخیره خروجی ------------------
def save_fragment(fragment, default_name="fragment"):
    fname = input(f"Enter output filename (default: {default_name}.txt): ").strip() or default_name
    outpath = os.path.join(OUTPUT_FOLDER, fname + ".txt")
    with open(outpath, "w", encoding="utf-8") as f:
        json.dump(fragment, f, ensure_ascii=False, indent=2)
    print(f"[green]✅ Saved {len(fragment)} items to {outpath}[/green]")

# ------------------ منوی حلقه خروجی ------------------
def menu_loop(valid_raw_configs, parsed_list, ping_results):
    fragments_dict = {
        "1": ("Fragment V1 (parsed) — VLESS ws/tls", fragment_v1),
        "2": ("Fragment V2 (parsed) — multi-protocol", fragment_v2),
        "3": ("Fragment V3 (raw+ping) — parse_general", fragment_v3),
        "5": ("Fragment V5 (normalized parsed) — generic", fragment_v5)
    }
    while True:
        print("\n[bold cyan]Select fragment to generate:[/bold cyan]")
        for k, v in fragments_dict.items():
            print(f"{k}. {v[0]}")
        print("0. Exit")
        choice = input("Enter choice: ").strip()
        if choice == "0":
            break
        if choice in fragments_dict:
            name, func = fragments_dict[choice]
            # تعیین ورودی مناسب برای هر تابع (بدون تغییر محتوای توابع)
            if choice == "1":
                # fragment_v1 => انتظار parsed dicts (همان parsed_list)
                output = func(parsed_list)
            elif choice == "2":
                # fragment_v2 => انتظار parsed dicts (parsed_list)
                output = func(parsed_list)
            elif choice == "3":
                # fragment_v3 => انتظار raw config strings + ping_results
                output = func(valid_raw_configs, ping_results)
            elif choice == "5":
                # fragment_v5 => انتظار parsed_configs با کلیدهای خاص؛ تبدیل parsed_list به فرم مورد نیاز
                normalized = []
                for p in parsed_list:
                    normalized.append({
                        "type": p.get("protocol", "vless"),
                        "server": p.get("address"),
                        "port": p.get("port"),
                        "uuid": p.get("id", p.get("user","")),
                        "name": p.get("remark", ""),
                        "tls": p.get("params", {}).get("security") == "tls",
                        "network": p.get("params", {}).get("type", "tcp"),
                        "password": p.get("params", {}).get("password", "")
                    })
                output = func(normalized)
            else:
                output = []
            if output is None:
                print("[red]❌ Function returned None or invalid output[/red]")
            else:
                save_fragment(output, default_name=name.replace(" ", "_"))
        else:
            print("[red]Invalid choice[/red]")

# ------------------ MAIN ------------------
if __name__ == "__main__":
    lines = get_input()
    valid_raw_configs, ping_results = process_configs(lines)
    parsed_list = []
    for cfg in valid_raw_configs:
        parsed = parse_vless_link(cfg)
        if parsed:
            parsed_list.append(parsed)
    menu_loop(valid_raw_configs, parsed_list, ping_results)

