#!/data/data/com.termux/files/usr/bin/python3
# health_v2_advanced.py
# مثل نسخه A + health http/https check برای تعیین Fastest بهتر
import os, re, json, yaml, subprocess, base64, socket, time, ssl, hashlib
from urllib.parse import urlparse, parse_qs
from concurrent.futures import ThreadPoolExecutor, as_completed

BASE_DIR = "/storage/emulated/0/Download/Akbar98"
os.makedirs(BASE_DIR, exist_ok=True)
INPUT_PATH = os.path.join(BASE_DIR, "input.txt")
with open(INPUT_PATH, "w", encoding="utf-8") as f: f.write("")
subprocess.call(["nano", INPUT_PATH])

out_folder = input("Enter output folder name in Download: ").strip()
if not out_folder:
    print("Folder name required."); exit(1)
OUT_DIR = os.path.join("/storage/emulated/0/Download", out_folder)
os.makedirs(OUT_DIR, exist_ok=True)
out_name = input("Enter output file name (without extension): ").strip()
if not out_name:
    print("File name required."); exit(1)
OUT_PATH = os.path.join(OUT_DIR, f"{out_name}.yaml")

def b64fix(s: str) -> str:
    s = s.strip().replace("\n", "").replace(" ", "")
    pad = len(s) % 4
    if pad:
        s += "=" * (4 - pad)
    return s

def safe_int(x, default=0):
    try:
        return int(x)
    except:
        return default

def sanitize(s: str) -> str:
    if not s:
        return ""
    return re.sub(r"[^A-Za-z0-9_\- .]", "", str(s)).strip()

_used_names = set()
def uniq_name(base: str) -> str:
    base = sanitize(base) or "Proxy"
    name = base
    i = 2
    while name in _used_names:
        name = f"{base} {i}"; i += 1
    _used_names.add(name)
    return name

def canonical_key(proxy: dict) -> str:
    proto = proxy.get("type","").lower()
    server = proxy.get("server","").lower()
    port = str(int(proxy.get("port",0)))
    if proto in ("vless","vmess"):
        ident = proxy.get("uuid","")
    elif proto == "trojan":
        ident = proxy.get("password","")
    elif proto in ("ss","shadowsocks"):
        ident = proxy.get("password","") + "|" + proxy.get("cipher","")
    else:
        ident = proxy.get("password","")
    net = proxy.get("network","tcp")
    tls = "tls" if proxy.get("tls") else "notls"
    key = "|".join([proto, f"{server}:{port}", ident, net, tls])
    return hashlib.sha1(key.encode()).hexdigest()

def tail(s: str, n=6):
    if not s:
        return ""
    s2 = re.sub(r"[-]", "", s)
    return s2[-n:] if len(s2) >= n else s2

def tcp_ping_ms(host, port, timeout=2.0):
    try:
        start = time.monotonic()
        sock = socket.create_connection((host, int(port)), timeout=timeout)
        sock.close()
        return int((time.monotonic() - start) * 1000)
    except Exception:
        return None

# simple HTTP HEAD check (supports https via ssl.wrap_socket)
def http_head_ok(host, port, path="/", use_tls=False, timeout=4.0):
    try:
        s = socket.create_connection((host, int(port)), timeout=timeout)
        if use_tls:
            ctx = ssl.create_default_context()
            s = ctx.wrap_socket(s, server_hostname=host)
        req = f"HEAD {path} HTTP/1.1\r\nHost: {host}\r\nConnection: close\r\nUser-Agent: health-check\r\n\r\n"
        s.send(req.encode())
        data = s.recv(512)
        s.close()
        return b"200" in data or b"204" in data or b"302" in data or b"301" in data
    except Exception:
        return False

# ---------------- parse (similar to A) ----------------
try:
    with open(INPUT_PATH, "r", encoding="utf-8") as f:
        lines = [ln.strip() for ln in f if ln.strip()]
except:
    lines = []

raw = []
def extract_json_objects(text):
    objs, stack, start = [], [], None
    for i, c in enumerate(text):
        if c == '{':
            if not stack: start = i
            stack.append(c)
        elif c == '}':
            if stack:
                stack.pop()
                if not stack and start is not None:
                    objs.append(text[start:i+1])
                    start = None
    return objs

whole = "\n".join(lines)
for frag in extract_json_objects(whole):
    try:
        obj = json.loads(frag)
    except:
        continue
    for ob in obj.get("outbounds", []) or []:
        proto = (ob.get("protocol") or "").lower()
        if proto not in ("vless","vmess","trojan","shadowsocks"):
            continue
        stream = ob.get("streamSettings") or {}
        net = (stream.get("network") or "tcp").lower()
        tls_flag = (ob.get("settings") or {}).get("security","").lower() in ("tls","reality")
        if proto in ("vless","vmess"):
            try:
                vnext=(ob.get("settings") or {}).get("vnext",[{}])[0]; user=(vnext.get("users") or [])[0]
            except:
                continue
            server=vnext.get("address") or ""; port=safe_int(vnext.get("port"),0); uid=user.get("id") or ""
            if not (server and port and uid): continue
            p={"type":proto,"server":server,"port":port,"network":net,"uuid":uid}
            if tls_flag: p["tls"]=True; p["servername"]=(stream.get("tlsSettings") or {}).get("serverName") or server
            raw.append(p)
        elif proto=="trojan":
            try: s=(ob.get("settings") or {}).get("servers",[{}])[0]
            except: continue
            server=s.get("address") or ""; port=safe_int(s.get("port"),0); pwd=s.get("password") or ""
            if not (server and port and pwd): continue
            raw.append({"type":"trojan","server":server,"port":port,"password":pwd,"network":"tcp","tls":True})
        elif proto=="shadowsocks":
            try: s=(ob.get("settings") or {}).get("servers",[{}])[0]
            except: continue
            server=s.get("address") or ""; port=safe_int(s.get("port"),0); cipher=s.get("method") or ""; pwd=s.get("password") or ""
            if not (server and port and cipher and pwd): continue
            raw.append({"type":"ss","server":server,"port":port,"cipher":cipher,"password":pwd,"network":"tcp"})

for line in lines:
    try:
        if line.startswith("vless://"):
            parsed=urlparse(line); uid=parsed.username or ""; host=parsed.hostname or ""; port=parsed.port or 443
            if not (uid and host and port): continue
            q=parse_qs(parsed.query); net=(q.get("type",["tcp"])[0]).lower(); tls_flag=(q.get("security",[""])[0].lower() in ("tls","reality"))
            p={"type":"vless","server":host,"port":int(port),"uuid":uid,"network":net}
            if tls_flag: p["tls"]=True; p["servername"]=q.get("sni",[host])[0]
            raw.append(p)
        elif line.startswith("vmess://"):
            payload=line[8:]
            try: info=json.loads(base64.b64decode(b64fix(payload)).decode(errors="ignore"))
            except: continue
            host=info.get("add") or ""; port=safe_int(info.get("port"),0); uid=info.get("id") or ""
            if not (host and port and uid): continue
            p={"type":"vmess","server":host,"port":port,"uuid":uid,"network":(info.get("net") or "tcp")}
            if str(info.get("tls","")).lower()=="tls": p["tls"]=True; p["servername"]=info.get("sni") or host
            raw.append(p)
        elif line.startswith("trojan://"):
            parsed=urlparse(line); pwd=parsed.username or ""; host=parsed.hostname or ""; port=parsed.port or 443
            if not (pwd and host and port): continue
            raw.append({"type":"trojan","server":host,"port":int(port),"password":pwd,"network":"tcp","tls":True})
        elif line.startswith("ss://"):
            try:
                after=line[5:]
                if "@" in after and ":" in after.split("@",1)[0]:
                    cred, rest = after.split("@",1); method,password = cred.split(":",1)
                    host_port = rest.split("#",1)[0]; host,port = host_port.rsplit(":",1)
                else:
                    if "@" not in after: continue
                    b64cred, rest = after.split("@",1)
                    method,password = base64.urlsafe_b64decode(b64fix(b64cred)).decode().split(":",1)
                    host_port = rest.split("#",1)[0]; host,port = host_port.rsplit(":",1)
                raw.append({"type":"ss","server":host.strip(),"port":safe_int(port,0),"cipher":method.strip(),"password":password.strip(),"network":"tcp"})
            except: continue
    except: continue

# dedupe + assign name
dedup={}
final=[]
for rp in raw:
    if not rp.get("server") or not rp.get("port"):
        continue
    key=canonical_key(rp)
    if key in dedup:
        ex=dedup[key]
        for k,v in rp.items():
            if not ex.get(k) and v:
                ex[k]=v
        continue
    name = uniq_name(f"{rp.get('type','proxy')}-{rp.get('server')}-{tail(str(rp.get('port')))}")
    rp["name"]=name
    dedup[key]=rp
    final.append(rp)

# advanced health: tcp + optional http HEAD to google generate_204
def health_check(p):
    host=p.get("server"); port=p.get("port")
    out = {"name":p["name"]}
    out.update(p)
    out["ping"]=None; out["status"]="dead"; out["http_ok"]=False
    if not host or not port:
        return out
    lat = tcp_ping_ms(host, port, timeout=3.0)
    if lat is None:
        out["ping"]=None; out["status"]="dead"
        return out
    out["ping"]=lat; out["status"]="ok"
    # try http head if tcp open and it's port 80/443 or tls True
    try_http = False
    use_tls = False
    if p.get("tls") or int(port) in (443, 8443):
        try_http = True; use_tls = True
    elif int(port) in (80, 8080):
        try_http = True; use_tls = False
    if try_http:
        # try HEAD to /generate_204 host: www.gstatic.com but using this proxy server as endpoint
        # note: here we test direct reachability of host:port by issuing HEAD /generate_204 to that host
        ok = False
        try:
            ok = http_head_ok(host=host, port=port, path="/generate_204", use_tls=use_tls, timeout=4.0)
        except:
            ok = False
        out["http_ok"] = ok
    return out

results=[]
if final:
    max_workers = min(60, len(final))
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futs={ex.submit(health_check, p): p for p in final}
        for fut in as_completed(futs):
            try:
                results.append(fut.result())
            except:
                pass

# recompose final_proxies (preserve order)
name_map = {r["name"]: r for r in results} if results else {p["name"]:p for p in final}
final_proxies = [name_map.get(p["name"], p) for p in final]

# choose fastest: prefer http_ok then lower ping
candidates = [p for p in final_proxies if p.get("status")=="ok"]
fast_sorted = sorted(candidates, key=lambda x: (0 if x.get("http_ok") else 1, x.get("ping", 99999)))
good_sorted = sorted([p for p in final_proxies if p.get("status")=="ok"], key=lambda x: x.get("ping",99999))
proxy_names = [p["name"] for p in final_proxies]

proxy_groups = [
    {"name":"GoodPing", "type":"select", "proxies": [p["name"] for p in good_sorted] or ["DIRECT"]},
    {"name":"Fastest", "type":"select", "proxies": [p["name"] for p in fast_sorted] or ["DIRECT"]},
    {"name":"LoadBalance", "type":"load-balance", "strategy":"round-robin", "proxies": proxy_names or ["DIRECT"]},
    {"name":"Backup", "type":"fallback", "url":"https://www.gstatic.com/generate_204", "interval":30, "tolerance":120, "proxies": ["DIRECT"] + (proxy_names or [])},
    {"name":"Auto-URLTest", "type":"url-test", "url":"https://www.gstatic.com/generate_204", "interval":25, "tolerance":50, "proxies": proxy_names or ["DIRECT"]},
    {"name":"Selector", "type":"select", "proxies": ["Fastest", "GoodPing", "Auto-URLTest", "LoadBalance", "DIRECT"] + (proxy_names or [])},
    {"name":"Direct", "type":"select", "proxies":["DIRECT"]},
    {"name":"Block", "type":"select", "proxies":["REJECT","DIRECT"]}
]

config = {
    "proxies": final_proxies,
    "proxy-groups": proxy_groups,
    "rules": ["MATCH,Selector"]
}

with open(OUT_PATH, "w", encoding="utf-8") as f:
    yaml.safe_dump(config, f, allow_unicode=True, sort_keys=False)

with open(INPUT_PATH, "w", encoding="utf-8") as f:
    f.write("")

print(f"[✅] Saved {len(final_proxies)} proxies to {OUT_PATH}")