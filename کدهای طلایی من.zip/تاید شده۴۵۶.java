import os
import re
import json
import yaml
import base64
import subprocess
from urllib.parse import quote, unquote, parse_qs
from rich import print

protocols = ["vless://", "vmess://", "trojan://", "ss://"]

def extract_host(config):
    match = re.search(r"@([^:/?#]+)", config)
    return match.group(1) if match else None

def ping_host(host):
    try:
        output = subprocess.check_output(
            ["ping", "-c", "3", "-W", "1", host],
            stderr=subprocess.DEVNULL
        ).decode()
        match = re.search(r"rtt min/avg/max/mdev = [\d.]+/([\d.]+)", output)
        return float(match.group(1)) if match else None
    except:
        return None

def classify_ping(ping):
    if ping is None:
        return "bad", "[bold red][BAD][/bold red]"
    elif ping < 150:
        return "good", "[bold green][GOOD][/bold green]"
    elif ping < 300:
        return "warn", "[bold yellow][WARN][/bold yellow]"
    else:
        return "bad", "[bold red][BAD][/bold red]"

def parse_link(link):
    link = link.strip()
    if link.startswith("vless://"):
        protocol = "vless"
    else:
        return None, None

    try:
        main_part = link.split("://")[1]
        if "#" in main_part:
            main_part, remark = main_part.split("#", 1)
        else:
            remark = ""

        if "?" in main_part:
            addr_port, params = main_part.split("?", 1)
            query = parse_qs(params)
        else:
            addr_port = main_part
            query = {}

        if '@' in addr_port:
            user, host_port = addr_port.split("@", 1)
        else:
            user = ""
            host_port = addr_port

        if ':' in host_port:
            address, port = host_port.split(":", 1)
        else:
            address, port = host_port, "443"

        parsed = {
            "protocol": protocol,
            "address": address,
            "port": int(port) if port.isdigit() else 443,
            "id": user,
            "params": {k: v[0] for k, v in query.items()},
            "remark": unquote(remark)
        }
        return protocol, parsed
    except:
        return None, None

# ======= تابع فرگمنت جدید =======
def build_fragment(parsed_configs):
    """
    دریافت لیست کانفیگ‌ها و ساخت Fragment JSON دقیق برای هر کانفیگ.
    خروجی استفاده شده در گزینه 1.
    """
    fragments = []
    for idx, cfg in enumerate(parsed_configs, 1):
        server = cfg.get("address")
        port = cfg.get("port")
        uuid = cfg.get("id")
        remark = cfg.get("remark", f"VLESS_{idx}")
        net = cfg.get("params", {}).get("type", "ws")
        sec = cfg.get("params", {}).get("security", "tls")
        path = cfg.get("params", {}).get("path", "/")
        host = cfg.get("params", {}).get("host", server)

        fragment = {
            "remarks": remark,
            "log": {"loglevel": "warning"},
            "inbounds": [
                {"port": 10808, "protocol": "socks", "settings": {"auth": "noauth", "udp": True}, "tag": "socks-in"},
                {"port": 10853, "protocol": "dokodemo-door", "settings": {"address": "1.1.1.1", "port": 53, "network": "tcp,udp"}, "tag": "dns-in"}
            ],
            "outbounds": [
                {
                    "tag": "proxy",
                    "protocol": "vless",
                    "settings": {"vnext": [{"address": server, "port": port, "users": [{"id": uuid, "encryption": "none"}]}]},
                    "streamSettings": {
                        "network": net,
                        "security": sec,
                        "sockopt": {"dialerProxy": "fragment"},
                        "wsSettings": {"path": path, "headers": {"Host": host}},
                        "tlsSettings": {"serverName": host, "fingerprint": "chrome", "alpn": ["http/1.1"]},
                    }
                },
                {
                    "tag": "fragment",
                    "protocol": "freedom",
                    "settings": {"fragment": {"packets": "tlshello", "length": "100-200", "interval": "1-1"}, "domainStrategy": "UseIPv4v6"}
                }
            ],
            "routing": {"domainStrategy": "IPIfNonMatch", "rules": [{"network": "tcp", "outboundTag": "proxy", "type": "field"}]}
        }
        fragments.append(fragment)
    return fragments

def save_output(configs):
    save_path = "/storage/emulated/0/Download/Akbar98"
    os.makedirs(save_path, exist_ok=True)

    while True:
        print("\n[bold cyan]📤 Choose output format:[/bold cyan]")
        print("1. Fragmented JSON")
        print("2. Simple JSON")
        print("3. TXT Summary")
        print("4. YAML File")
        print("0. Exit")

        choice = input("👉 Enter option (0-4): ").strip()
        if choice == "0":
            break

        file_name = input("📁 Enter filename (without extension): ").strip()
        if not file_name:
            print("[red]❌ Filename cannot be empty[/red]")
            continue

        full_path = ""
        if choice == "1":
            output_data = build_fragment(configs)
            full_path = os.path.join(save_path, file_name + ".json")
            with open(full_path, "w", encoding="utf-8") as f:
                json.dump(output_data, f, indent=2, ensure_ascii=False)

        elif choice == "2":
            full_path = os.path.join(save_path, file_name + ".json")
            with open(full_path, "w", encoding="utf-8") as f:
                json.dump(configs, f, indent=2, ensure_ascii=False)

        elif choice == "3":
            lines = []
            for i, cfg in enumerate(configs, 1):
                lines.append(f"{i}. vless://{cfg['id']}@{cfg['address']}:{cfg['port']}  remark: {cfg['remark']}")
            full_path = os.path.join(save_path, file_name + ".txt")
            with open(full_path, "w", encoding="utf-8") as f:
                f.write("\n".join(lines))

        elif choice == "4":
            full_path = os.path.join(save_path, file_name + ".yaml")
            with open(full_path, "w", encoding="utf-8") as f:
                yaml.dump(configs, f, allow_unicode=True)

        else:
            print("[red]❌ Invalid choice[/red]")
            continue

        print(f"[bold green]✅ Saved at: {full_path}[/bold green]")
        print("[cyan]Choose next option or 0 to exit[/cyan]")

def main():
    print("[cyan]Paste your configs (Ctrl+D to finish):[/cyan]")
    lines = []
    while True:
        try:
            line = input()
            if line.strip():
                lines.append(line.strip())
        except EOFError:
            break

    good_configs = []
    for line in lines:
        if not any(line.startswith(p) for p in protocols):
            continue

        host = extract_host(line)
        if not host:
            print(f"[bold red][INVALID][/bold red] {line}")
            continue

        ping = ping_host(host)
        status, label = classify_ping(ping)
        print(f"{label} {host} - {ping if ping else 'NO REPLY'}ms")

        if status == "good":
            proto, parsed = parse_link(line)
            if proto:
                good_configs.append(parsed)

    if not good_configs:
        print("[red]❌ No good configs found[/red]")
        return

    save_output(good_configs)

if __name__ == "__main__":
    main()
