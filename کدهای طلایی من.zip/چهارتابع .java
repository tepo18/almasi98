import os
import re
import json
import subprocess
from urllib.parse import unquote, parse_qs
from rich import print

# ------------------ مسیر خروجی ------------------
OUTPUT_FOLDER = "/storage/emulated/0/Download/almasi98"
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

PROTOCOLS = ["vless://", "vmess://", "trojan://", "ss://"]

# ------------------ ورودی ------------------
def get_input():
    print("[bold cyan]Paste your configs (Ctrl+D to finish):[/bold cyan]")
    lines = []
    while True:
        try:
            line = input().strip()
            if line:
                lines.append(line)
        except EOFError:
            break
    return lines

# ------------------ استخراج هاست و پینگ ------------------
def extract_host(config):
    match = re.search(r"@([^:/?#]+)", config)
    return match.group(1) if match else None

def ping_host(host):
    try:
        output = subprocess.check_output(
            ["ping", "-c", "3", "-W", "1", host],
            stderr=subprocess.DEVNULL
        ).decode(errors="ignore")
        match = re.search(r"rtt min/avg/max/(?:mdev|stddev) = [\d.]+/([\d.]+)", output)
        return float(match.group(1)) if match else None
    except:
        return None

def classify_ping(ping):
    if ping is None:
        return "bad", "[bold red][BAD][/bold red]"
    elif ping < 150:
        return "good", "[bold green][GOOD][/bold green]"
    elif ping < 300:
        return "warn", "[bold yellow][WARN][/bold yellow]"
    else:
        return "bad", "[bold red][BAD][/bold red]"

# ------------------ پارس لینک ------------------
def parse_vless_link(link):
    try:
        main = link.split("://", 1)[1]
        remark = ""
        if "#" in main:
            main, remark = main.split("#", 1)
            remark = unquote(remark)
        if "?" in main:
            addr_port, params = main.split("?", 1)
            query = parse_qs(params)
        else:
            addr_port = main
            query = {}
        if "@" in addr_port:
            user_id, host_port = addr_port.split("@", 1)
        else:
            user_id = ""
            host_port = addr_port
        if ":" in host_port:
            address, port = host_port.split(":", 1)
        else:
            address = host_port
            port = 443
        return {
            "protocol": "vless",
            "address": address,
            "port": int(port),
            "id": user_id,
            "params": {k: v[0] for k, v in query.items()},
            "remark": remark or link
        }
    except:
        return None

# ------------------ پنج Fragment ------------------
def fragment_v1(configs):
    fragments = []
    for i, cfg in enumerate(configs):
        outbound = {
            "tag": "proxy",
            "protocol": "vless",
            "settings": {
                "vnext": [{
                    "address": cfg["address"],
                    "port": cfg["port"],
                    "users": [{
                        "id": cfg["id"],
                        "encryption": cfg["params"].get("encryption", "none"),
                        "flow": cfg["params"].get("flow", "")
                    }]
                }]
            },
            "streamSettings": {
                "network": cfg["params"].get("type", "ws"),
                "security": cfg["params"].get("security", "tls"),
                "sockopt": {"dialerProxy": "fragment"},
                "tlsSettings": {
                    "serverName": cfg["params"].get("sni", cfg["params"].get("host", cfg["address"])),
                    "fingerprint": cfg["params"].get("fp", "chrome"),
                    "alpn": cfg["params"].get("alpn", "").split(",") if "alpn" in cfg["params"] else ["http/1.1"]
                },
                "wsSettings": {
                    "path": cfg["params"].get("path", "/"),
                    "headers": {"Host": cfg["params"].get("host", cfg["address"])}
                }
            }
        }
        fragment = {
            "remarks": cfg["remark"] or f"💦 {i+1} - VLESS",
            "log": {"loglevel": "warning"},
            "dns": {
                "servers": [
                    {"address": "https://8.8.8.8/dns-query", "tag": "remote-dns"},
                    {"address": "8.8.8.8", "domains": [f"full:{cfg['address']}"], "skipFallback": True}
                ],
                "queryStrategy": "UseIP",
                "tag": "dns"
            },
            "inbounds": [
                {"port": 10808, "protocol": "socks", "settings": {"auth": "noauth", "udp": True, "userLevel": 8},
                 "sniffing": {"destOverride": ["http","tls"], "enabled": True, "routeOnly": True}, "tag": "socks-in"},
                {"port": 10853, "protocol": "dokodemo-door", "settings": {"address":"1.1.1.1","network":"tcp,udp","port":53},"tag":"dns-in"}
            ],
            "outbounds":[outbound,
                {"tag":"fragment","protocol":"freedom","settings":{"fragment":{"packets":"tlshello","length":"100-200","interval":"1-1"},"domainStrategy":"UseIPv4v6"}}
            ],
            "routing":{"domainStrategy":"IPIfNonMatch","rules":[{"inboundTag":["dns-in"],"outboundTag":"dns-out","type":"field"},{"network":"tcp","outboundTag":"proxy","type":"field"}]}
        }
        fragments.append(fragment)
    return fragments

def fragment_v2(configs):
    fragments = []
    for idx, cfg in enumerate(configs, 1):
        proto = cfg.get("protocol", "vless")
        server = cfg.get("address")
        port = cfg.get("port")
        uuid = cfg.get("id", "")
        name = cfg.get("remark", f"proxy{idx}")
        tls = cfg.get("params", {}).get("security", "none") == "tls"
        network = cfg.get("params", {}).get("type", "tcp")
        password = cfg.get("params", {}).get("password", "")

        outbound = None
        if proto in ["vless", "vmess"]:
            outbound = {"tag":"proxy","protocol":proto,"settings":{"vnext":[{"address":server,"port":port,"users":[{"id":uuid,"encryption":"none"}]}]},"streamSettings":{"network":network,"security":"tls" if tls else "none"}}
        elif proto == "trojan":
            outbound = {"tag":"proxy","protocol":"trojan","settings":{"servers":[{"address":server,"port":port,"password":password}]},"streamSettings":{"network":network,"security":"tls" if tls else "none"}}
        elif proto in ["ss", "shadowsocks"]:
            outbound = {"tag":"proxy","protocol":"shadowsocks","settings":{"servers":[{"address":server,"port":port,"password":password,"method":"aes-128-gcm"}]},"streamSettings":{"network":network,"security":"none"}}
        else:
            continue

        fragment = {"remarks": name,"log":{"loglevel":"warning"},"inbounds":[{"port":10808,"protocol":"socks","settings":{"auth":"noauth","udp":True,"userLevel":8},"tag":"socks-in"}],"outbounds":[outbound,{"tag":"fragment","protocol":"freedom","settings":{"fragment":{"packets":"tlshello","length":"100-200","interval":"1-1"},"domainStrategy":"UseIPv4v6"}}],"routing":{"domainStrategy":"IPIfNonMatch","rules":[{"network":"tcp","outboundTag":"proxy","type":"field"}]}}    
        fragments.append(fragment)
    return fragments

def fragment_v4(configs):
    fragments = []
    for i, cfg in enumerate(configs):  
        outbound = {  
            "tag": "proxy",  
            "protocol": "vless",  
            "settings": {  
                "vnext": [{  
                    "address": cfg["address"],  
                    "port": cfg["port"],  
                    "users": [{  
                        "id": cfg["id"],  
                        "encryption": cfg["params"].get("encryption", "none"),  
                        "flow": cfg["params"].get("flow", "")  
                    }]  
                }]  
            },  
            "streamSettings": {  
                "network": cfg["params"].get("type", "ws"),  
                "security": cfg["params"].get("security", "tls"),  
                "sockopt": {"dialerProxy": "fragment"},  
                "tlsSettings": {  
                    "serverName": cfg["params"].get("sni", cfg["params"].get("host", cfg["address"])),  
                    "fingerprint": cfg["params"].get("fp", "chrome"),  
                    "alpn": cfg["params"].get("alpn", "").split(",") if "alpn" in cfg["params"] else ["http/1.1"]  
                },  
                "wsSettings": {  
                    "path": cfg["params"].get("path", "/"),  
                    "headers": {"Host": cfg["params"].get("host", cfg["address"])}  
                }  
            }  
        }  

        fragment = {  
            "remarks": cfg["remark"] or f"💦 {i+1} - VLESS",  
            "log": {"loglevel": "warning"},  
            "dns": {  
                "servers": [  
                    {"address": "https://8.8.8.8/dns-query", "tag": "remote-dns"},  
                    {"address": "8.8.8.8", "domains": [f"full:{cfg['address']}"], "skipFallback": True}  
                ],  
                "queryStrategy": "UseIP",  
                "tag": "dns"  
            },  
            "inbounds": [  
                {"port": 10808, "protocol": "socks", "settings": {"auth": "noauth", "udp": True, "userLevel": 8},  
                 "sniffing": {"destOverride": ["http", "tls"], "enabled": True, "routeOnly": True}, "tag": "socks-in"},  
                {"port": 10853, "protocol": "dokodemo-door", "settings": {"address": "1.1.1.1", "network": "tcp,udp", "port": 53}, "tag": "dns-in"}  
            ],  
            "outbounds": [outbound,  
                {"tag": "fragment", "protocol": "freedom", "settings": {"fragment": {"packets": "tlshello", "length": "100-200", "interval": "1-1"}, "domainStrategy": "UseIPv4v6"}}  
            ],  
            "routing": {"domainStrategy": "IPIfNonMatch", "rules": [  
                {"inboundTag": ["dns-in"], "outboundTag": "dns-out", "type": "field"},  
                {"network": "tcp", "outboundTag": "proxy", "type": "field"}  
            ]}  
        }  

        fragments.append(fragment)  

    return fragments

def fragment_v5(configs):
    fragments = []
    for idx, cfg in enumerate(configs,1):
        proto = cfg.get("protocol","vless")
        server = cfg.get("address")
        port = cfg.get("port")
        user = cfg.get("id","")
        remark = cfg.get("remark",f"proxy{idx}")
        network = cfg.get("params",{}).get("type","tcp")
        tls = cfg.get("params",{}).get("security","none")=="tls"

        outbound = {"tag":"proxy","protocol":proto,"settings":{"vnext":[{"address":server,"port":port,"users":[{"id":user,"encryption":"none"}]}]},"streamSettings":{"network":network,"security":"tls" if tls else "none"}}
        fragment={"remarks":remark,"log":{"loglevel":"warning"},"inbounds":[{"port":10808,"protocol":"socks","settings":{"auth":"noauth","udp":True,"userLevel":8},"tag":"socks-in"},{"port":10853,"protocol":"dokodemo-door","settings":{"address":"1.1.1.1","port":53,"network":"tcp,udp"},"tag":"dns-in"}],"outbounds":[outbound,{"tag":"fragment","protocol":"freedom","settings":{"fragment":{"packets":"tlshello","length":"100-200","interval":"1-1"},"domainStrategy":"UseIPv4v6"}}],"routing":{"domainStrategy":"IPIfNonMatch","rules":[{"network":"tcp","outboundTag":"proxy","type":"field"}]}}
        fragments.append(fragment)
    return fragments

# ------------------ ذخیره خروجی ------------------
def save_fragment(fragment, default_name="fragment"):
    fname = input(f"Enter output filename (default: {default_name}.txt): ").strip() or default_name
    outpath = os.path.join(OUTPUT_FOLDER, fname + ".txt")
    with open(outpath, "w", encoding="utf-8") as f:
        json.dump(fragment, f, ensure_ascii=False, indent=2)
    print(f"[green]✅ Saved {len(fragment)} items to {outpath}[/green]")

# ------------------ منوی انتخاب Fragment ------------------
def menu_loop(valid_raw_configs, parsed_list, ping_results):
    fragments_dict = {
        "1": ("Fragment V1 (parsed) — VLESS ws/tls", fragment_v1),
        "2": ("Fragment V2 (parsed) — multi-protocol", fragment_v2),
        "4": ("Fragment V4 (raw) — parse_link based", fragment_v4),
        "5": ("Fragment V5 (normalized parsed) — generic", fragment_v5)
    }
    while True:
        print("\n[bold cyan]Select fragment to generate:[/bold cyan]")
        for k, v in fragments_dict.items():
            print(f"{k}. {v[0]}")
        print("0. Exit")
        choice = input("Enter choice: ").strip()
        if choice == "0":
            break
        if choice in fragments_dict:
            name, func = fragments_dict[choice]
            if choice == "1":
                output = func(parsed_list)
            elif choice == "2":
                output = func(parsed_list)
            elif choice == "4":
                output = func(parsed_list)
            elif choice == "5":
                normalized = []
                for p in parsed_list:
                    normalized.append({
                        "protocol": p.get("protocol", "vless"),
                        "address": p.get("address"),
                        "port": p.get("port"),
                        "id": p.get("id",""),
                        "remark": p.get("remark",""),
                        "params": p.get("params", {})
                    })
                output = func(normalized)
            else:
                output = []
            if output is None:
                print("[red]❌ Function returned None or invalid output[/red]")
            else:
                save_fragment(output, default_name=name.replace(" ", "_"))
        else:
            print("[red]Invalid choice[/red]")

# ------------------ پردازش کانفیگ‌ها ------------------
def process_configs(lines):
    valid_raw_configs = []
    ping_results = {}
    for line in lines:
        if not any(line.startswith(p) for p in PROTOCOLS):
            continue
        host = extract_host(line)
        if not host:
            print(f"[red][INVALID][/red] {line}")
            continue
        ping = ping_host(host)
        status, label = classify_ping(ping)
        print(f"{label} {host} - {ping if ping else 'NO REPLY'}ms")
        if status in ["good", "warn"]:
            valid_raw_configs.append(line)
            ping_results[line] = ping
    return valid_raw_configs, ping_results

# ------------------ MAIN ------------------
if __name__ == "__main__":
    lines = get_input()
    valid_raw_configs, ping_results = process_configs(lines)
    if not valid_raw_configs:
        print("[red]❌ No good configs found[/red]")
    else:
        parsed_list = []
        for cfg in valid_raw_configs:
            parsed = parse_vless_link(cfg)
            if parsed:
                parsed_list.append(parsed)
        menu_loop(valid_raw_configs, parsed_list, ping_results)

