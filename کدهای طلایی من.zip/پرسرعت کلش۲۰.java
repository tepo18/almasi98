#!/data/data/com.termux/files/usr/bin/python3
import os, re, json, yaml, subprocess, base64, socket, time
from urllib.parse import urlparse, parse_qs
from concurrent.futures import ThreadPoolExecutor, as_completed

BASE_DIR = "/storage/emulated/0/Download/Akbar98"
os.makedirs(BASE_DIR, exist_ok=True)
INPUT_PATH = os.path.join(BASE_DIR, "input.txt")

with open(INPUT_PATH,"w",encoding="utf-8") as f: f.write("")
subprocess.call(["nano",INPUT_PATH])

out_folder=input("Enter output folder name in Download: ").strip()
if not out_folder: print("Folder required"); exit(1)
OUT_DIR=os.path.join("/storage/emulated/0/Download",out_folder)
os.makedirs(OUT_DIR,exist_ok=True)

out_name=input("Enter output file name (without extension): ").strip()
if not out_name: print("File required"); exit(1)
OUT_PATH=os.path.join(OUT_DIR,f"{out_name}.yaml")

def b64fix(s:str)->str:
    s=s.strip().replace("\n","").replace(" ","")
    pad=len(s)%4
    if pad: s+="="*(4-pad)
    return s

def safe_int(x,default=0):
    try: return int(x)
    except: return default

def sanitize(s:str)->str:
    if not s: return ""
    return re.sub(r"[^A-Za-z0-9_\- .]","",str(s)).strip()

_used_names=set()
def uniq_name(base:str)->str:
    base=sanitize(base) or "Proxy"
    name=base;i=2
    while name in _used_names:
        name=f"{base} {i}"; i+=1
    _used_names.add(name)
    return name

def tail(s:str,n=6):
    if not s: return ""
    s2=re.sub(r"[-]","",s)
    return s2[-n:] if len(s2)>=n else s2

def tcp_ping_ms(host,port,timeout=2.0):
    try:
        start=time.monotonic()
        sock=socket.create_connection((host,int(port)),timeout=timeout)
        sock.close()
        return int((time.monotonic()-start)*1000)
    except: return None

try:
    with open(INPUT_PATH,"r",encoding="utf-8") as f: content=f.read()
except: content=""

proxies=[]
lines=[ln.strip() for ln in content.splitlines() if ln.strip()]
for line in lines:
    try:
        if line.startswith("vless://"):
            parsed=urlparse(line)
            uid=parsed.username or ""
            host=parsed.hostname or ""
            port=parsed.port or 443
            q=parse_qs(parsed.query)
            if not (uid and host and port): continue
            net=(q.get("type",["tcp"])[0] or "tcp").lower()
            tls_flag=(q.get("security",[""])[0] or "").lower() in ("tls","reality")
            name=uniq_name(f"vless-{host}-{tail(uid)}")
            p={"name":name,"type":"vless","server":host,"port":port,"uuid":uid,
               "encryption":"none","udp":True,"network":net}
            if net=="ws":
                p["ws-opts"]={"path":q.get("path",["/"])[0]}
                hosth=q.get("host",[]) or q.get("Host",[])
                if hosth: p["ws-opts"]["headers"]={"Host":hosth[0]}
            if tls_flag: p["tls"]=True; p["servername"]=q.get("sni",[])[0] if q.get("sni",[]) else host
            proxies.append(p)
        elif line.startswith("vmess://"):
            payload=line[8:]
            decoded=base64.b64decode(b64fix(payload)).decode(errors="ignore")
            info=json.loads(decoded)
            host=info.get("add") or info.get("server") or ""
            port=safe_int(info.get("port"),0)
            uid=info.get("id") or ""
            if not (host and port and uid): continue
            net=(info.get("net") or "tcp").lower()
            tls_flag=str(info.get("tls","")).lower()=="tls"
            name=uniq_name(f"vmess-{host}-{tail(uid)}")
            p={"name":name,"type":"vmess","server":host,"port":port,"uuid":uid,
               "alterId":safe_int(info.get("aid",info.get("alterId",0))),
               "cipher":info.get("scy","auto"),"udp":True,"network":net}
            if net=="ws":
                p["ws-opts"]={"path":info.get("path") or "/"}
                hosth=info.get("host") or ""
                if hosth: p["ws-opts"]["headers"]={"Host":hosth}
            if tls_flag: p["tls"]=True; p["servername"]=info.get("sni") or host
            proxies.append(p)
        elif line.startswith("trojan://"):
            parsed=urlparse(line)
            pwd=parsed.username or ""
            host=parsed.hostname or ""
            port=parsed.port or 443
            if not (pwd and host and port): continue
            q=parse_qs(parsed.query)
            sni=q.get("sni",[host])[0]
            name=uniq_name(f"trojan-{host}-{tail(pwd)}")
            p={"name":name,"type":"trojan","server":host,"port":port,
               "password":pwd,"udp":True,"network":"tcp","tls":True,"sni":sni}
            proxies.append(p)
        elif line.startswith("ss://"):
            try:
                after=line[5:]
                if "@" in after:
                    cred,rest=after.split("@",1)
                    if ":" in cred: method,password=cred.split(":",1)
                    else: continue
                    host_port=rest.split("#",1)[0]
                    if ":" not in host_port: continue
                    host,port=host_port.rsplit(":",1)
                else: continue
                method=method.strip(); password=password.strip()
                host=host.strip(); port=safe_int(port.strip(),0)
                if not (method and password and host and port): continue
                name=uniq_name(f"ss-{host}-{port}")
                p={"name":name,"type":"ss","server":host,"port":port,
                   "cipher":method,"password":password,"udp":True}
                proxies.append(p)
            except: continue
    except: continue

def check_and_attach_ping(proxy):
    host=proxy.get("server"); port=proxy.get("port")
    if not host or not port: proxy["ping"]=None; proxy["status"]="dead"; return proxy
    lat=tcp_ping_ms(host,port,timeout=3.0)
    if lat is None: proxy["ping"]=None; proxy["status"]="dead"
    else: proxy["ping"]=lat; proxy["status"]="ok"
    return proxy

results=[]
if proxies:
    max_workers=min(40,len(proxies))
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futs={ex.submit(check_and_attach_ping,p):idx for idx,p in enumerate(proxies)}
        for fut in as_completed(futs):
            try: results.append(fut.result())
            except: pass

name_map={p["name"]:p for p in results} if results else {p["name"]:p for p in proxies}
final_proxies=[name_map.get(p["name"],p) for p in proxies]

fast_sorted=sorted([p for p in final_proxies if p.get("status")=="ok"], key=lambda x:x.get("ping",99999))

proxy_names=[p["name"] for p in final_proxies]

config={
    "proxies":final_proxies,
    "proxy-groups":[
        {"name":"Fast","type":"select","proxies":[p["name"] for p in fast_sorted]},
        {"name":"Manual","type":"select","proxies":proxy_names},
        {"name":"Auto-URLTest","type":"url-test","url":"https://www.gstatic.com/generate_204",
         "interval":25,"tolerance":50,"proxies":proxy_names},
        {"name":"Direct","type":"select","proxies":["DIRECT"]},
        {"name":"Block","type":"select","proxies":["REJECT","DIRECT"]}
    ],
    "rules":["MATCH,Fast"]    
}

with open(OUT_PATH,"w",encoding="utf-8") as f:
    yaml.safe_dump(config,f,allow_unicode=True,sort_keys=False)

with open(INPUT_PATH,"w",encoding="utf-8") as f: f.write("")

print(f"[✅] Saved {len(final_proxies)} proxies to {OUT_PATH} (Fast Version)")