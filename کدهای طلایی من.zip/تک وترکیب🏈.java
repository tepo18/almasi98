import os
import re
import subprocess
import json
import base64
from urllib.parse import parse_qs, unquote
from rich import print
from rich.prompt import Prompt
import random

# ------------------ Settings ------------------
OUTPUT_FOLDER = "/storage/emulated/0/Download/almasi98"
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# ------------------ Helpers ------------------
def safe_b64_decode(s: str):
    s = s.strip()
    padding = len(s) % 4
    if padding:
        s += "=" * (4 - padding)
    try:
        return base64.b64decode(s).decode(errors="ignore")
    except Exception:
        return None

def ping_host(host: str):
    try:
        output = subprocess.check_output(
            ["ping", "-c", "3", "-W", "1", host],
            stderr=subprocess.DEVNULL
        ).decode()
        match = re.search(r"rtt min/avg/max/mdev = [\d.]+/([\d.]+)", output)
        return float(match.group(1)) if match else None
    except Exception:
        return None

def classify_ping(ping):
    if ping is None:
        return "bad", "[bold red][BAD][/bold red]"
    elif ping < 150:
        return "good", "[bold green][GOOD][/bold green]"
    elif ping < 300:
        return "warn", "[bold yellow][WARN][/bold yellow]"
    else:
        return "bad", "[bold red][BAD][/bold red]"

def strip_protocol(link: str) -> str:
    if "://" in link:
        return link.split("://", 1)[1]
    return link

def extract_host(config):
    match = re.search(r"@([^:/?#]+)", config)
    return match.group(1) if match else None

# ------------------ Parsers ------------------
def parse_vless(link: str):
    try:
        rest = link.split("://", 1)[1]
        remark = ""
        if "#" in rest:
            rest, remark = rest.split("#", 1)
        if "?" in rest:
            addr_port, params = rest.split("?", 1)
            query = parse_qs(params)
        else:
            addr_port = rest
            query = {}
        if "@" in addr_port:
            user, host_port = addr_port.split("@", 1)
        else:
            user = ""
            host_port = addr_port
        if ":" in host_port:
            address, port = host_port.split(":", 1)
        else:
            address = host_port
            port = "443"
        return {
            "protocol": "vless",
            "raw": link,
            "address": address,
            "port": int(port) if port.isdigit() else 443,
            "id": user,
            "params": {k:v[0] for k,v in query.items()},
            "remark": unquote(remark)
        }
    except:
        return None

def parse_trojan(link: str):
    try:
        rest = link.split("://",1)[1]
        remark = ""
        if "#" in rest:
            rest, remark = rest.split("#",1)
        if "?" in rest:
            addr_port, params = rest.split("?",1)
            query = parse_qs(params)
        else:
            addr_port = rest
            query = {}
        if "@" in addr_port:
            passwd, host_port = addr_port.split("@",1)
        else:
            passwd = ""
            host_port = addr_port
        if ":" in host_port:
            address, port = host_port.split(":",1)
        else:
            address = host_port
            port = "443"
        return {
            "protocol":"trojan",
            "raw":link,
            "address":address,
            "port":int(port) if port.isdigit() else 443,
            "id":passwd,
            "params":{k:v[0] for k,v in query.items()},
            "remark":unquote(remark)
        }
    except:
        return None

def parse_ss(link: str):
    try:
        main = link.split("://",1)[1]
        remark = ""
        if "#" in main:
            main, remark = main.split("#",1)
        remark = unquote(remark)
        if "@" in main and ":" in main.split("@",1)[1]:
            method_pass, host_port = main.split("@",1)
            if ":" in method_pass:
                method,password = method_pass.split(":",1)
            else:
                method,password = method_pass,""
            if ":" in host_port:
                address, port = host_port.split(":",1)
            else:
                address, port = host_port, "443"
            return {
                "protocol":"ss",
                "raw":link,
                "address":address,
                "port":int(port) if port.isdigit() else 443,
                "id":password,
                "method":method,
                "params":{},
                "remark":remark
            }
        else:
            decoded = safe_b64_decode(main)
            if decoded and "@" in decoded:
                method_pass, host_port = decoded.split("@",1)
                if ":" in method_pass:
                    method,password = method_pass.split(":",1)
                else:
                    method,password = method_pass,""
                if ":" in host_port:
                    address, port = host_port.split(":",1)
                else:
                    address, port = host_port, "443"
                return {
                    "protocol":"ss",
                    "raw":link,
                    "address":address,
                    "port":int(port) if port.isdigit() else 443,
                    "id":password,
                    "method":method,
                    "params":{},
                    "remark":remark
                }
    except:
        return None
    return None

def parse_config(conf: str):
    conf = conf.strip()
    if conf.startswith("vless://"): return parse_vless(conf)
    if conf.startswith("trojan://"): return parse_trojan(conf)
    if conf.startswith("ss://"): return parse_ss(conf)
    return None

# ------------------ Fragment V4 (NEW) ------------------
def fragment_v4(configs):
    fragments = []
    for i, cfg in enumerate(configs):  
        outbound = {  
            "tag": "proxy",  
            "protocol": "vless",  
            "settings": {  
                "vnext": [{  
                    "address": cfg["address"],  
                    "port": cfg["port"],  
                    "users": [{  
                        "id": cfg["id"],  
                        "encryption": cfg["params"].get("encryption", "none"),  
                        "flow": cfg["params"].get("flow", "")  
                    }]  
                }]  
            },  
            "streamSettings": {  
                "network": cfg["params"].get("type", "ws"),  
                "security": cfg["params"].get("security", "tls"),  
                "sockopt": {"dialerProxy": "fragment"},  
                "tlsSettings": {  
                    "serverName": cfg["params"].get("sni", cfg["params"].get("host", cfg["address"])),  
                    "fingerprint": cfg["params"].get("fp", "chrome"),  
                    "alpn": cfg["params"].get("alpn", "").split(",") if "alpn" in cfg["params"] else ["http/1.1"]  
                },  
                "wsSettings": {  
                    "path": cfg["params"].get("path", "/"),  
                    "headers": {"Host": cfg["params"].get("host", cfg["address"])}  
                }  
            }  
        }  

        fragment = {  
            "remarks": cfg["remark"] or f"💦 {i+1} - VLESS",  
            "log": {"loglevel": "warning"},  
            "dns": {  
                "servers": [  
                    {"address": "https://8.8.8.8/dns-query", "tag": "remote-dns"},  
                    {"address": "8.8.8.8", "domains": [f"full:{cfg['address']}"], "skipFallback": True}  
                ],  
                "queryStrategy": "UseIP",  
                "tag": "dns"  
            },  
            "inbounds": [  
                {"port": 10808, "protocol": "socks", "settings": {"auth": "noauth", "udp": True, "userLevel": 8},  
                 "sniffing": {"destOverride": ["http", "tls"], "enabled": True, "routeOnly": True}, "tag": "socks-in"},  
                {"port": 10853, "protocol": "dokodemo-door", "settings": {"address": "1.1.1.1", "network": "tcp,udp", "port": 53}, "tag": "dns-in"}  
            ],  
            "outbounds": [outbound,  
                {"tag": "fragment", "protocol": "freedom", "settings": {"fragment":{"packets": "tlshello","length": "100-200","interval": "1-1"}, "domainStrategy":"UseIPv4v6"}}  
            ],  
            "routing": {"domainStrategy": "IPIfNonMatch", "rules": [  
                {"inboundTag": ["dns-in"], "outboundTag": "dns-out", "type": "field"},  
                {"network": "tcp", "outboundTag": "proxy", "type": "field"}  
            ]}  
        }  

        fragments.append(fragment)  

    return fragments

# ------------------ Fragment V1-V3 (مثال) ------------------
def fragment_v1(configs):
    fragments = []  # Placeholder fragment function
    return fragments

def fragment_v2(configs):
    fragments = []  # Placeholder fragment function
    return fragments

def fragment_v3(configs, ping_results):
    fragments = []  # Placeholder fragment function
    return fragments

# ------------------ Main ------------------
def main():
    print("[bold cyan]Enter your configs line by line (VLESS/Trojan/SS only). Ctrl+D when done:[/bold cyan]")
    configs=[]
    while True:
        try:
            line=input()
            if line.strip():
                configs.append(line.strip())
        except EOFError:
            break

    if not configs:
        print("[bold red]No configs entered![/bold red]")
        return

    parsed_list=[]
    protocol_count={"vless":0,"trojan":0,"ss":0,"ignored":0}

    for conf in configs:
        parsed=parse_config(conf)
        if not parsed:
            protocol_count["ignored"]+=1
            print(f"[bold yellow]Ignored (unsupported or invalid):[/bold yellow] {conf}")
            continue
        proto=parsed["protocol"]
        protocol_count[proto]+=1
        parsed_list.append(parsed)
        print(f"[bold cyan]{proto.upper()}[/bold cyan] {parsed['remark']}")

    print("\n[bold green]Summary:[/bold green]")
    for k,v in protocol_count.items():
        print(f"{k}: {v}")
    print(f"Total parsed configs: {len(parsed_list)}")

    while True:
        print("\n[cyan]Choose output type:[/cyan]")
        print("1) Fragment V4 (JSON)")
        print("0) Exit")
        choice = input("Enter choice: ").strip()
        if choice=="0":
            break
        elif choice=="1":
            fragments = fragment_v4(parsed_list)
            filename = Prompt.ask("Enter output file name for Fragment JSON (without extension)")
            filepath = os.path.join(OUTPUT_FOLDER, f"{filename}.json")
            with open(filepath,"w",encoding="utf-8") as f:
                json.dump(fragments,f,ensure_ascii=False,indent=2)
            print(f"[bold green]Fragment JSON saved:[/bold green] {filepath}")
        else:
            print("[bold red]Invalid choice![/bold red]")

if __name__=="__main__":
    main()
