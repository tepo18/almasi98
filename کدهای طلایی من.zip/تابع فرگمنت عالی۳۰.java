def fragment_v1(configs):
    fragments = []
    for i, cfg in enumerate(configs):
        outbound = {
            "tag":"proxy",
            "protocol":"vless",
            "settings":{"vnext":[{"address":cfg["address"],"port":cfg["port"],"users":[{"id":cfg["id"],"encryption":cfg["params"].get("encryption","none"),"flow":cfg["params"].get("flow","")}]}]},
            "streamSettings":{"network":cfg["params"].get("type","ws"),"security":cfg["params"].get("security","tls"),"sockopt":{"dialerProxy":"fragment"},"tlsSettings":{"serverName":cfg["params"].get("sni",cfg["params"].get("host",cfg["address"])),"fingerprint":cfg["params"].get("fp","chrome"),"alpn":cfg["params"].get("alpn","http/1.1").split(",") if "alpn" in cfg["params"] else ["http/1.1"]},"wsSettings":{"path":cfg["params"].get("path","/"),"headers":{"Host":cfg["params"].get("host",cfg["address"])}}}}
        fragment={"remarks":cfg["remark"] or f"💦 {i+1} - VLESS","log":{"loglevel":"warning"},"dns":{"servers":[{"address":"https://8.8.8.8/dns-query","tag":"remote-dns"},{"address":"8.8.8.8","domains":[f"full:{cfg['address']}"],"skipFallback":True}],"queryStrategy":"UseIP","tag":"dns"},"inbounds":[{"port":10808,"protocol":"socks","settings":{"auth":"noauth","udp":True,"userLevel":8},"sniffing":{"destOverride":["http","tls"],"enabled":True,"routeOnly":True},"tag":"socks-in"},{"port":10853,"protocol":"dokodemo-door","settings":{"address":"1.1.1.1","network":"tcp,udp","port":53},"tag":"dns-in"}],"outbounds":[outbound,{"tag":"fragment","protocol":"freedom","settings":{"fragment":{"packets":"tlshello","length":"100-200","interval":"1-1"},"domainStrategy":"UseIPv4v6"}}],"routing":{"domainStrategy":"IPIfNonMatch","rules":[{"inboundTag":["dns-in"],"outboundTag":"dns-out","type":"field"},{"network":"tcp","outboundTag":"proxy","type":"field"}]}}
        fragments.append(fragment)
    return fragments