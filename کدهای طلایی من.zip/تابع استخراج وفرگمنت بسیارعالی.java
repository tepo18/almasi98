# ==================== توابع استخراج ====================
def parse_link(link):
    link = link.strip()
    proto = None
    if link.startswith("vless://"):
        proto = "vless"
    elif link.startswith("trojan://"):
        proto = "trojan"
    elif link.startswith("ss://"):
        proto = "shadowsocks"
    elif link.startswith("grpc://"):
        proto = "grpc"
    else:
        return None

    try:
        main = link.split("://")[1]
        remark = ""
        if "#" in main:
            main, remark = main.split("#", 1)
        if "?" in main:
            addr_port, params = main.split("?", 1)
            query = urllib.parse.parse_qs(params)
        else:
            addr_port = main
            query = {}

        if "@" in addr_port:
            user, host_port = addr_port.split("@", 1)
        else:
            user = ""
            host_port = addr_port

        if ":" in host_port:
            address, port = host_port.split(":", 1)
        else:
            address, port = host_port, "443"

        parsed = {
            "protocol": proto,
            "address": address,
            "port": int(port),
            "id": user,
            "params": {k: v[0] for k, v in query.items()},
            "remark": urllib.parse.unquote(remark) or address
        }
        return parsed
    except:
        return None

# ==================== ساخت fragment ساپورت‌شده ====================
def build_fragment(configs):
    fragments = []
    for cfg in configs:
        parsed = parse_link(cfg)
        if not parsed:
            continue

        proto = parsed["protocol"]
        outbound = {}
        streamSettings = {}
        if proto == "vless" or proto == "grpc":
            network = parsed["params"].get("type", "ws") if proto=="vless" else "grpc"
            security = parsed["params"].get("security", "none")
            flow = parsed["params"].get("flow", "")
            streamSettings = {
                "network": network,
                "security": security,
                "tlsSettings": {
                    "serverName": parsed["params"].get("sni", parsed["address"]),
                    "fingerprint": "chrome",
                    "alpn": ["http/1.1"]
                },
                "sockopt": {"dialerProxy": "fragment"},
            }
            if network == "ws":
                streamSettings["wsSettings"] = {
                    "path": parsed["params"].get("path", "/"),
                    "headers": {"Host": parsed["params"].get("host", parsed["address"])}
                }
            outbound = {
                "tag": "proxy",
                "protocol": "vless",
                "settings": {
                    "vnext": [{
                        "address": parsed["address"],
                        "port": parsed["port"],
                        "users": [{
                            "id": parsed["id"],
                            "encryption": "none",
                            "flow": flow
                        }]
                    }]
                },
                "streamSettings": streamSettings
            }

        elif proto == "trojan":
            outbound = {
                "tag": "proxy",
                "protocol": "trojan",
                "settings": {"servers":[{"address": parsed["address"], "port": parsed["port"], "password": parsed["id"]}]},
                "streamSettings": {"network": parsed["params"].get("type","tcp"), "sockopt": {"dialerProxy": "fragment"}}
            }
        elif proto == "shadowsocks":
            outbound = {
                "tag": "proxy",
                "protocol": "shadowsocks",
                "settings": {"servers":[{"address": parsed["address"], "port": parsed["port"], "method": parsed["params"].get("method","aes-128-gcm"), "password": parsed["id"]}]}
            }

        fragment = {
            "remarks": parsed["remark"],
            "log": {"loglevel":"warning"},
            "dns": {
                "servers":[
                    {"address":"https://8.8.8.8/dns-query","tag":"remote-dns"},
                    {"address":"8.8.8.8","domains":[f"full:{parsed['address']}"],"skipFallback":True}
                ],
                "queryStrategy":"UseIP",
                "tag":"dns"
            },
            "inbounds":[
                {"port":10808,"protocol":"socks","settings":{"auth":"noauth","udp":True,"userLevel":8},"sniffing":{"destOverride":["http","tls"],"enabled":True,"routeOnly":True},"tag":"socks-in"},
                {"port":10853,"protocol":"dokodemo-door","settings":{"address":"1.1.1.1","network":"tcp,udp","port":53},"tag":"dns-in"}
            ],
            "outbounds":[
                outbound,
                {"tag":"fragment","protocol":"freedom","settings":{"fragment":{"packets":"tlshello","length":"100-200","interval":"1-1"},"domainStrategy":"UseIPv4v6"}}
            ],
            "routing":{
                "domainStrategy":"IPIfNonMatch",
                "rules":[
                    {"inboundTag":["dns-in"],"outboundTag":"dns-out","type":"field"},
                    {"network":"tcp","outboundTag":"proxy","type":"field"}
                ]
            }
        }
        fragments.append(fragment)
    return fragments