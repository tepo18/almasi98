import os
import re
import subprocess
import base64
import json
import urllib.parse
from rich import print
from rich.table import Table

# ------------------ Settings ------------------
SAVE_DIR = "/sdcard/Download/almasi98/"
os.makedirs(SAVE_DIR, exist_ok=True)

PROTOCOLS = ("vless://", "vmess://", "trojan://", "ss://", "ssss://")
MAX_COMBOS_PER_BATCH = 50

# ------------------ Input + Ping + Stats ------------------
def extract_host(config: str):
    m = re.search(r"@([^:/?#\s]+)", config)
    if m:
        return m.group(1)
    m = re.search(r"://([^:/?#\s]+)", config)
    return m.group(1) if m else None

def ping_host(host: str):
    try:
        out = subprocess.check_output(
            ["ping", "-c", "3", "-W", "1", host],
            stderr=subprocess.DEVNULL
        ).decode()
        m = re.search(r"rtt min/avg/max/mdev = [\d.]+/([\d.]+)", out)
        return float(m.group(1)) if m else None
    except Exception:
        return None

def classify_ping(avg_ms: float | None):
    if avg_ms is None:
        return "bad", "[bold red][BAD][/bold red]"
    if avg_ms < 150:
        return "good", "[bold green][GOOD][/bold green]"
    if avg_ms < 300:
        return "warn", "[bold yellow][WARN][/bold yellow]"
    return "bad", "[bold red][BAD][/bold red]"

def get_input():
    print("[cyan]Choose input method:[/cyan]")
    print("1) Manual paste configs (Ctrl+D to finish)")
    print("2) Paste a subscription (base64 text)")
    choice = input("Enter choice [1/2]: ").strip()
    lines = []

    if choice == "1":
        print("[bold cyan]Paste your configs (Ctrl+D to finish):[/bold cyan]")
        try:
            while True:
                line = input()
                if line.strip():
                    lines.append(line.strip())
        except EOFError:
            pass
    elif choice == "2":
        b64 = input("Paste base64 subscription text: ").strip()
        try:
            decoded = base64.b64decode(b64).decode(errors="ignore")
            lines = [ln.strip() for ln in decoded.splitlines() if ln.strip()]
        except Exception as e:
            print(f"[red]Failed to decode subscription: {e}[/red]")
    else:
        print("[red]Invalid choice.[/red]")

    return lines

def module_input_ping():
    raw = get_input()
    total_raw = len(raw)
    all_valid = []
    proto_counts = {"vless": 0, "vmess": 0, "trojan": 0, "ss": 0}

    print("\n[bold cyan]Pinging hosts...[/bold cyan]\n")
    for cfg in raw:
        if not cfg.startswith(PROTOCOLS):
            continue

        host = extract_host(cfg)
        if not host:
            print(f"[bold red][INVALID][/bold red] {cfg}")
            continue

        avg = ping_host(host)
        status, label = classify_ping(avg)
        ms = f"{avg:.0f}ms" if avg is not None else "NO REPLY"
        print(f"{label} {host} - {ms}")

        if status in ["good", "warn"]:
            all_valid.append(cfg)

        if cfg.startswith("vless://"):
            proto_counts["vless"] += 1
        elif cfg.startswith("vmess://"):
            proto_counts["vmess"] += 1
        elif cfg.startswith("trojan://"):
            proto_counts["trojan"] += 1
        elif cfg.startswith("ss://") or cfg.startswith("ssss://"):
            proto_counts["ss"] += 1

    table = Table(title="Configs Summary")
    table.add_column("Category")
    table.add_column("Count")
    table.add_row("All raw lines", str(total_raw))
    table.add_row("All valid links", str(len(all_valid)))
    table.add_row("vless", str(proto_counts["vless"]))
    table.add_row("vmess", str(proto_counts["vmess"]))
    table.add_row("trojan", str(proto_counts["trojan"]))
    table.add_row("ss", str(proto_counts["ss"]))
    print()
    print(table)

    return all_valid

# ------------------ Helpers ------------------
def ask_filename(default_name: str):
    name = input(f"Enter filename (default: {default_name}): ").strip()
    if not name:
        name = default_name
    if not name.endswith(".txt") and not name.endswith(".json"):
        name += ".txt"
    return os.path.join(SAVE_DIR, name)

def strip_protocol(link: str) -> str:
    if "://" in link:
        return link.split("://", 1)[1]
    return link

# ------------------ Combo Generators ------------------
def generate_combo2_consume(configs: list[str], offset: int = 0) -> list[str]:
    combos2 = []
    remaining = configs[offset:].copy()
    while len(remaining) >= 2 and len(combos2) < MAX_COMBOS_PER_BATCH:
        first = remaining.pop(0)
        second = remaining.pop(0)
        combos2.append(f"{first}+{second}")
    return combos2

def generate_combo3_consume(configs: list[str], offset: int = 0) -> list[str]:
    combos3 = []
    remaining = configs[offset:].copy()
    while len(remaining) >= 3 and len(combos3) < MAX_COMBOS_PER_BATCH:
        first = remaining.pop(0)
        second = remaining.pop(0)
        third = remaining.pop(0)
        tail = strip_protocol(third)
        combos3.append(f"{first}+{second}+ss//{tail}")
    return combos3

# ------------------ Fragment Builder ------------------
def parse_link(link):
    link = link.strip()
    parsed = {}

    if link.startswith("vless://"):
        protocol = "vless"
    else:
        return None, None

    try:
        main_part = link.split("://")[1]
        if "#" in main_part:
            main_part, remark = main_part.split("#", 1)
        else:
            remark = ""

        if "?" in main_part:
            addr_port, params = main_part.split("?", 1)
            query = urllib.parse.parse_qs(params)
        else:
            addr_port = main_part
            query = {}

        if '@' in addr_port:
            user, host_port = addr_port.split("@", 1)
        else:
            user = ""
            host_port = addr_port

        if ':' in host_port:
            address, port = host_port.split(":", 1)
        else:
            address, port = host_port, "443"

        parsed = {
            "protocol": protocol,
            "address": address,
            "port": int(port) if port.isdigit() else 443,
            "id": user,
            "params": {k: v[0] for k, v in query.items()},
            "remark": urllib.parse.unquote(remark)
        }
        return protocol, parsed

    except Exception:
        return None, None

def build_fragment_list(configs):
    fragments = []

    for i, cfg in enumerate(configs):
        outbound = {
            "tag": "proxy",
            "protocol": "vless",
            "settings": {
                "vnext": [{
                    "address": cfg["address"],
                    "port": cfg["port"],
                    "users": [{
                        "id": cfg["id"],
                        "encryption": cfg["params"].get("encryption", "none"),
                        "flow": cfg["params"].get("flow", "")
                    }]
                }]
            },
            "streamSettings": {
                "network": cfg["params"].get("type", "ws"),
                "security": cfg["params"].get("security", "tls"),
                "sockopt": {"dialerProxy": "fragment"},
                "tlsSettings": {
                    "serverName": cfg["params"].get("sni", cfg["params"].get("host", cfg["address"])),
                    "fingerprint": cfg["params"].get("fp", "chrome"),
                    "alpn": cfg["params"].get("alpn", "").split(",") if "alpn" in cfg["params"] else ["http/1.1"]
                },
                "wsSettings": {
                    "path": cfg["params"].get("path", "/"),
                    "headers": {"Host": cfg["params"].get("host", cfg["address"])}
                }
            }
        }

        fragment = {
            "remarks": cfg["remark"] or f"💦 {i+1} - VLESS",
            "log": {"loglevel": "warning"},
            "dns": {
                "servers": [
                    {"address": "https://8.8.8.8/dns-query", "tag": "remote-dns"},
                    {"address": "8.8.8.8", "domains": [f"full:{cfg['address']}"], "skipFallback": True}
                ],
                "queryStrategy": "UseIP",
                "tag": "dns"
            },
            "inbounds": [
                {
                    "port": 10808,
                    "protocol": "socks",
                    "settings": {"auth": "noauth", "udp": True, "userLevel": 8},
                    "sniffing": {"destOverride": ["http", "tls"], "enabled": True, "routeOnly": True},
                    "tag": "socks-in"
                },
                {
                    "port": 10853,
                    "protocol": "dokodemo-door",
                    "settings": {"address": "1.1.1.1", "network": "tcp,udp", "port": 53},
                    "tag": "dns-in"
                }
            ],
            "outbounds": [
                outbound,
                {
                    "tag": "fragment",
                    "protocol": "freedom",
                    "settings": {
                        "fragment": {"packets": "tlshello", "length": "100-200", "interval": "1-1"},
                        "domainStrategy": "UseIPv4v6"
                    }
                }
            ],
            "routing": {
                "domainStrategy": "IPIfNonMatch",
                "rules": [
                    {"inboundTag": ["dns-in"], "outboundTag": "dns-out", "type": "field"},
                    {"network": "tcp", "outboundTag": "proxy", "type": "field"}
                ]
            }
        }

        fragments.append(fragment)

    return fragments

# ------------------ Outputs Menu ------------------
def outputs_menu(configs: list[str]):
    combo2_offset = 0
    combo3_offset = 0

    while True:
        print("\n[cyan]Choose output type:[/cyan]")
        print("1) Combo-2 (50 each time)")
        print("2) Combo-3 (50 each time)")
        print("3) Fragment (JSON output)")

        choice = input("Enter choice: ").strip()
        if choice == "1":
            combos2 = generate_combo2_consume(configs, combo2_offset)
            if not combos2:
                print("[red]No more combos left for Combo-2.[/red]")
                continue
            combo2_offset += len(combos2)
            path = ask_filename(f"combo2_{combo2_offset}.txt")
            with open(path, "w", encoding="utf-8") as f:
                f.write("\n".join(combos2))
            print(f"[green]Saved Combo-2 batch ({len(combos2)}):[/green] {path}")
        elif choice == "2":
            combos3 = generate_combo3_consume(configs, combo3_offset)
            if not combos3:
                print("[red]No more combos left for Combo-3.[/red]")
                continue
            combo3_offset += len(combos3)
            path = ask_filename(f"combo3_{combo3_offset}.txt")
            with open(path, "w", encoding="utf-8") as f:
                f.write("\n".join(combos3))
            print(f"[green]Saved Combo-3 batch ({len(combos3)}):[/green] {path}")
        elif choice == "3":
            path = ask_filename("fragment.json")
            parsed = []
            for c in configs:
                proto, p = parse_link(c)
                if p:
                    parsed.append(p)
            frag = build_fragment_list(parsed)
            with open(path, "w", encoding="utf-8") as f:
                json.dump(frag, f, indent=2, ensure_ascii=False)
            print(f"[green]Saved Fragment JSON:[/green] {path}")

# ------------------ MAIN ------------------
def main():
    accepted = module_input_ping()
    if not accepted:
        print("[red]No valid configs to process.[/red]")
        return
    outputs_menu(accepted)

if __name__ == "__main__":
    main()
