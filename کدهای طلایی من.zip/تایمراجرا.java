
name: without-timer

on:
  # فقط روی push به شاخه main اجرا شود
  push:
    branches:
      - main
  # اجازه اجرای دستی از طریق رابط کاربری گیت‌هاب
  workflow_dispatch:
  # بخش schedule حذف شد

permissions:
  contents: write # مجوز نوشتن برای پوش کردن لازم است

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout code
        uses: actions/checkout@v4

      - name: Configure Git Credentials
        run: |
          git config user.name github-actions[bot]
          git config user.email 41898282+github-actions[bot]@users.noreply.github.com

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: 3.x # یا نسخه دقیق‌تر مثل '3.11'

      # Cache steps (اختیاری)
      - name: Set weekly cache key
        run: echo "cache_id=$(date --utc '+%V')" >> $GITHUB_ENV

      - name: Cache dependencies
        uses: actions/cache@v4
        with:
          key: pip-cache-${{ runner.os }}-${{ steps.setup-python.outputs.python-version }}-${{ hashFiles('**/requirements.txt') }}-${{ env.cache_id }}
          path: ~/.cache/pip
          restore-keys: |
            pip-cache-${{ runner.os }}-${{ steps.setup-python.outputs.python-version }}-

      - name: Install dependencies
        # بهتره یک فایل requirements.txt بسازید و از اون استفاده کنید:
        # run: pip install -r requirements.txt
        run: pip install requests psutil retrying PyYaml # <--- وابستگی‌های خودت رو اینجا بذار

      - name: Set execute permissions
        run: |
          chmod +x xray/xray
          chmod +x hy2/hysteria


      - name: Run checker script
        run: python cl.py # <--- اسکریپت اصلی پایتون شما

      # ----- مراحل کامیت و پوش کردن نتایج -----
      - name: Commit and Push changes
        run: |
          # نام فایل‌های خروجی که می‌خواهید کامیت شوند
          FILE1="final.txt"

          # بررسی اینکه آیا در *هر کدام* از فایل‌ها تغییری وجود دارد
          # git status --porcelain بدون آرگومان همه تغییرات را لیست می‌کند
          if [[ -n $(git status --porcelain $FILE1) ]]; then
            echo "Changes detected in $FILE1. Committing..."
            # --- هر دو فایل را اضافه کنید ---
            git add $FILE1
            # -------------------------------
            # پیام کامیت را کمی عمومی‌تر کنید
            git commit -m "chore: Update results ($FILE1) [skip ci]"
            git push origin HEAD:main
          else
            echo "No changes detected in $FILE1. Nothing to commit."
          fi