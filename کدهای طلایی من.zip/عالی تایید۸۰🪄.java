import os
import json
import urllib.parse
import yaml
import re
import subprocess
from rich import print
from rich.table import Table

PROTOCOLS = ["vless://", "vmess://", "trojan://", "ss://"]

# ---------- مسیر ثابت خروجی ----------
SAVE_DIR = "/storage/emulated/0/Download/almasi98"
os.makedirs(SAVE_DIR, exist_ok=True)

# ------------------ Input & Ping Module ------------------
def get_input():
    print("[bold cyan]Paste your configs (Ctrl+D to finish):[/bold cyan]")
    lines = []
    while True:
        try:
            line = input().strip()
            if line:
                lines.append(line)
        except EOFError:
            break
    return lines

def extract_host(config):
    match = re.search(r"@([^:/?#]+)", config)
    return match.group(1) if match else None

def ping_host(host):
    try:
        output = subprocess.check_output(
            ["ping", "-c", "3", "-W", "1", host],
            stderr=subprocess.DEVNULL
        ).decode()
        match = re.search(r"rtt min/avg/max/mdev = [\d.]+/([\d.]+)", output)
        return float(match.group(1)) if match else None
    except:
        return None

def classify_ping(ping):
    if ping is None or ping < 1:
        return "red", "[bold red][BAD][/bold red]"
    elif ping <= 1500:
        return "green", "[bold green][GOOD][/bold green]"
    else:
        return "yellow", "[bold yellow][WARN][/bold yellow]"

def process_configs(lines):
    total_raw = len(lines)
    green, yellow, red = [], [], []
    valid_configs = []

    for line in lines:
        if not any(line.startswith(p) for p in PROTOCOLS):
            continue
        host = extract_host(line)
        if not host:
            print(f"[red][INVALID][/red] {line}")
            continue
        ping = ping_host(host)
        status, label = classify_ping(ping)
        ms_str = f"{ping:.2f}" if isinstance(ping, (int, float)) else "NO REPLY"
        print(f"{label} {host} - {ms_str} ms")
        if status in ["green", "yellow"]:
            valid_configs.append(line)
            if status == "green":
                green.append(line)
            else:
                yellow.append(line)
        else:
            red.append(line)

    table = Table(title="Ping & Config Summary")
    table.add_column("Metric")
    table.add_column("Value")
    table.add_row("Total input", str(total_raw))
    table.add_row("Valid (Green+Yellow)", str(len(valid_configs)))
    table.add_row("Green ping", str(len(green)))
    table.add_row("Yellow ping", str(len(yellow)))
    table.add_row("Red ping / Bad", str(len(red)))
    print(table)

    return valid_configs

# ------------------ VLESS Parser ------------------
def parse_link(link):
    link = link.strip()
    if link.startswith("vless://"):
        protocol = "vless"
    else:
        return None, None

    try:
        main_part = link.split("://")[1]
        remark = ""
        if "#" in main_part:
            main_part, remark = main_part.split("#", 1)

        if "?" in main_part:
            addr_port, params = main_part.split("?", 1)
            query = urllib.parse.parse_qs(params)
        else:
            addr_port = main_part
            query = {}

        if '@' in addr_port:
            user, host_port = addr_port.split("@", 1)
        else:
            user = ""
            host_port = addr_port

        if ':' in host_port:
            address, port = host_port.split(":", 1)
        else:
            address, port = host_port, "443"

        parsed = {
            "protocol": protocol,
            "address": address,
            "port": int(port),
            "id": user,
            "params": {k: v[0] for k, v in query.items()},
            "remark": urllib.parse.unquote(remark)
        }
        return protocol, parsed

    except Exception:
        return None, None

# ------------------ Output Builders ------------------
def build_fragment_list(configs):
    fragments = []
    for i, cfg in enumerate(configs):
        fragment = {
            "remarks": cfg["remark"] or f"💦 {i+1} - VLESS",
            "log": {"loglevel": "warning"},
            "dns": {
                "servers": [
                    {"address": "https://8.8.8.8/dns-query", "tag": "remote-dns"},
                    {"address": "8.8.8.8", "domains": [f"full:{cfg['address']}"], "skipFallback": True}
                ],
                "queryStrategy": "UseIP",
                "tag": "dns"
            },
            "inbounds": [
                {
                    "port": 10808,
                    "protocol": "socks",
                    "settings": {"auth": "noauth", "udp": True, "userLevel": 8},
                    "sniffing": {"destOverride": ["http", "tls"], "enabled": True, "routeOnly": True},
                    "tag": "socks-in"
                },
                {
                    "port": 10853,
                    "protocol": "dokodemo-door",
                    "settings": {"address": "1.1.1.1", "network": "tcp,udp", "port": 53},
                    "tag": "dns-in"
                }
            ],
            "outbounds": [
                {
                    "tag": "proxy",
                    "protocol": "vless",
                    "settings": {
                        "vnext": [{
                            "address": cfg["address"],
                            "port": cfg["port"],
                            "users": [{"id": cfg["id"], "encryption": cfg["params"].get("encryption", "none"), "flow": cfg["params"].get("flow", "")}]
                        }]
                    },
                    "streamSettings": {
                        "network": cfg["params"].get("type", "ws"),
                        "security": cfg["params"].get("security", "tls"),
                        "sockopt": {"dialerProxy": "fragment"},
                        "tlsSettings": {
                            "serverName": cfg["params"].get("sni", cfg["params"].get("host", cfg["address"])),
                            "fingerprint": cfg["params"].get("fp", "chrome"),
                            "alpn": cfg["params"].get("alpn", "").split(",") if "alpn" in cfg["params"] else ["http/1.1"]
                        },
                        "wsSettings": {
                            "path": cfg["params"].get("path", "/"),
                            "headers": {"Host": cfg["params"].get("host", cfg["address"])}
                        }
                    }
                },
                {"tag": "fragment", "protocol": "freedom", "settings": {"fragment": {"packets": "tlshello", "length": "100-200", "interval": "1-1"}, "domainStrategy": "UseIPv4v6"}}
            ],
            "routing": {"domainStrategy": "IPIfNonMatch", "rules": [{"inboundTag": ["dns-in"], "outboundTag": "dns-out", "type": "field"}, {"network": "tcp", "outboundTag": "proxy", "type": "field"}]}
        }
        fragments.append(fragment)
    return fragments

def build_neko_format(configs):
    neko_list = []
    for i, cfg in enumerate(configs):
        neko_list.append({
            "remarks": cfg["remark"] or f"Neko-{i+1}",
            "outbounds": [{
                "protocol": "vless",
                "settings": {
                    "vnext": [{"address": cfg["address"], "port": cfg["port"], "users": [{"id": cfg["id"], "encryption": cfg["params"].get("encryption", "none"), "flow": cfg["params"].get("flow", "")}]}]
                },
                "streamSettings": {
                    "network": cfg["params"].get("type", "ws"),
                    "security": cfg["params"].get("security", "tls"),
                    "tlsSettings": {"serverName": cfg["params"].get("sni", cfg["params"].get("host", cfg["address"]))},
                    "wsSettings": {"path": cfg["params"].get("path", "/"), "headers": {"Host": cfg["params"].get("host", cfg["address"])}}}
            }]
        })
    return neko_list

def build_clash_yaml(configs):
    proxies = []
    proxy_names = []

    for i, cfg in enumerate(configs):
        name = cfg["remark"] or f"Node-{i+1}"
        proxy = {
            "name": name,
            "type": "vless",
            "server": cfg["address"],
            "port": cfg["port"],
            "uuid": cfg["id"],
            "tls": True if cfg["params"].get("security", "tls") == "tls" else False,
            "udp": True,
            "servername": cfg["params"].get("sni", cfg["params"].get("host", cfg["address"])),
            "fingerprint": cfg["params"].get("fp", "chrome"),
            "network": cfg["params"].get("type", "ws"),
            "ws-opts": {"path": cfg["params"].get("path", "/"), "headers": {"Host": cfg["params"].get("host", cfg["address"])}}}
        proxies.append(proxy)
        proxy_names.append(name)

    clash_config = {
        "proxies": proxies,
        "proxy-groups": [
            {"name": "♻️ Auto", "type": "url-test", "proxies": proxy_names, "url": "http://www.gstatic.com/generate_204", "interval": 300},
            {"name": "🔰 All", "type": "select", "proxies": proxy_names}],
        "rules": ["MATCH,🔰 All"]
    }
    return clash_config

# ------------------ Save Output ------------------
def save_output(configs):
    while True:
        print("\n🧩 Select output type:")
        print("1. Fragmented V2Ray")
        print("2. Raw JSON Array")
        print("3. NekoBox JSON")
        print("4. Clash Meta YAML")
        choice = input("🔢 Your choice (1/2/3/4): ").strip()
        file_name = input("📁 Output file name (no extension): ").strip()

        if choice == "4":
            full_path = os.path.join(SAVE_DIR, f"{file_name}.yaml")
        else:
            full_path = os.path.join(SAVE_DIR, f"{file_name}.json")

        if choice == "1":
            output = build_fragment_list(configs)
            with open(full_path, "w", encoding="utf-8") as f:
                json.dump(output, f, indent=2, ensure_ascii=False)
        elif choice == "2":
            with open(full_path, "w", encoding="utf-8") as f:
                json.dump(configs, f, indent=2, ensure_ascii=False)
        elif choice == "3":
            output = build_neko_format(configs)
            with open(full_path, "w", encoding="utf-8") as f:
                json.dump(output, f, indent=2, ensure_ascii=False)
        elif choice == "4":
            output = build_clash_yaml(configs)
            with open(full_path, "w", encoding="utf-8") as f:
                yaml.dump(output, f, sort_keys=False)
        else:
            print("❌ Invalid choice.")
            continue

        print(f"\n✅ Saved to: {full_path}")
        again = input("🔁 Export another format? (y/n): ").strip().lower()
        if again != "y":
            break

# ------------------ MAIN ------------------
def main():
    lines = get_input()
    filtered_configs = process_configs(lines)
    if not filtered_configs:
        print("❌ No valid configs to export.")
        return

    # پارس لینک‌ها
    parsed_configs = []
    for line in filtered_configs:
        proto, parsed = parse_link(line)
        if parsed:
            parsed_configs.append(parsed)

    print(f"\n✅ {len(parsed_configs)} configs ready for export.")
    save_output(parsed_configs)

if __name__ == "__main__":
    main()
