def build_fragment_list(configs: list):
    fragments = []
    for i, cfg in enumerate(configs, start=1):
        params = cfg.get("params", {})
        network = params.get("type", "ws")
        security = params.get("security", "tls")

        server_name = params.get("sni") or params.get("host") or cfg["address"]
        alpn_raw = params.get("alpn", "")
        alpn = [p for p in (alpn_raw.split(",") if alpn_raw else []) if p] or ["http/1.1"]

        stream_settings = {
            "network": network,
            "security": security,
            "sockopt": {"dialerProxy": "fragment"}
        }

        if security == "tls":
            stream_settings["tlsSettings"] = {
                "serverName": server_name,
                "fingerprint": params.get("fp", "chrome"),
                "alpn": alpn
            }

        if network == "ws":
            stream_settings["wsSettings"] = {
                "path": params.get("path", "/"),
                "headers": {"Host": params.get("host") or server_name}
            }

        outbound_proxy = {
            "tag": "proxy",
            "protocol": "vless",
            "settings": {
                "vnext": [{
                    "address": cfg["address"],
                    "port": cfg["port"],
                    "users": [{
                        "id": cfg["id"],
                        "encryption": params.get("encryption", "none"),
                        "flow": params.get("flow", "")
                    }]
                }]
            },
            "streamSettings": stream_settings
        }

        outbound_fragment = {
            "tag": "fragment",
            "protocol": "freedom",
            "settings": {
                "fragment": {
                    "packets": "tlshello",
                    "length": "100-200",
                    "interval": "1-1"
                },
                "domainStrategy": "UseIPv4v6"
            }
        }

        inbound_socks = {
            "port": 10808,
            "protocol": "socks",
            "settings": {"auth": "noauth", "udp": True, "userLevel": 8},
            "sniffing": {"destOverride": ["http", "tls"], "enabled": True, "routeOnly": True},
            "tag": "socks-in"
        }

        inbound_dns = {
            "port": 10853,
            "protocol": "dokodemo-door",
            "settings": {
                "address": "1.1.1.1",
                "network": "tcp,udp",
                "port": 53
            },
            "tag": "dns-in"
        }

        routing = {
            "domainStrategy": "IPIfNonMatch",
            "rules": [
                {
                    "inboundTag": ["dns-in"],
                    "outboundTag": "dns-out",
                    "type": "field"
                },
                {
                    "network": "tcp",
                    "outboundTag": "proxy",
                    "type": "field"
                }
            ]
        }

        fragment = {
            "remarks": cfg.get("remark") or f"💦 {i} - VLESS",
            "log": {"loglevel": "warning"},
            "inbounds": [inbound_socks, inbound_dns],
            "outbounds": [outbound_proxy, outbound_fragment],
            "routing": routing
        }

        fragments.append(fragment)

    return fragments