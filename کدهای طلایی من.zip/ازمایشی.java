#!/data/data/com.termux/files/usr/bin/python3
# Clash Smart Switch - نسخه اصلاح شده با گروه‌های پر
import os, re, json, yaml, subprocess, base64, socket, time, hashlib
from urllib.parse import urlparse, parse_qs
from concurrent.futures import ThreadPoolExecutor, as_completed

BASE_DIR = "/storage/emulated/0/Download/Akbar98"
os.makedirs(BASE_DIR, exist_ok=True)
INPUT_PATH = os.path.join(BASE_DIR, "input.txt")
with open(INPUT_PATH, "w", encoding="utf-8") as f: f.write("")
subprocess.call(["nano", INPUT_PATH])

out_folder = input("Enter output folder name in Download: ").strip()
if not out_folder: print("Folder name required."); exit(1)
OUT_DIR = os.path.join("/storage/emulated/0/Download", out_folder)
os.makedirs(OUT_DIR, exist_ok=True)
out_name = input("Enter output file name (without extension): ").strip()
if not out_name: print("File name required."); exit(1)
OUT_PATH = os.path.join(OUT_DIR, f"{out_name}.yaml")

def b64fix(s: str) -> str:
    s = s.strip().replace("\n","").replace(" ","")
    pad = len(s) % 4
    if pad: s += "="*(4-pad)
    return s

def safe_int(x, default=0):
    try: return int(x)
    except: return default

def sanitize(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9_\- .]","", str(s)).strip() if s else ""

_used_names = set()
def uniq_name(base: str) -> str:
    base = sanitize(base) or "Proxy"
    name = base
    i = 2
    while name in _used_names:
        name = f"{base} {i}"; i+=1
    _used_names.add(name)
    return name

def tail(s: str, n=6) -> str:
    s2 = re.sub(r"[-]","", s) if s else ""
    return s2[-n:] if len(s2)>=n else s2

def canonical_key(proxy: dict) -> str:
    proto = proxy.get("type","").lower()
    server = proxy.get("server","").lower()
    port = str(int(proxy.get("port",0)))
    if proto in ("vless","vmess"): ident = proxy.get("uuid","")
    elif proto=="trojan": ident=proxy.get("password","")
    elif proto in ("ss","shadowsocks"): ident=proxy.get("password","")+"|"+proxy.get("cipher","")
    else: ident=proxy.get("password","")
    net=proxy.get("network","tcp")
    tls="tls" if proxy.get("tls") else "notls"
    key="|".join([proto,f"{server}:{port}",ident,net,tls])
    return hashlib.sha1(key.encode()).hexdigest()

def tcp_ping_ms(host,port,timeout=2.0):
    try:
        start=time.monotonic()
        sock=socket.create_connection((host,int(port)),timeout=timeout)
        sock.close()
        return int((time.monotonic()-start)*1000)
    except: return None

def multi_ping_summary(host,port,attempts=3,timeout=2.0,pause=0.12):
    success=0
    pings=[]
    for _ in range(attempts):
        lat=tcp_ping_ms(host,port,timeout)
        if lat is not None: success+=1; pings.append(lat)
        time.sleep(pause)
    avg=int(sum(pings)/len(pings)) if pings else None
    return {"success":success,"attempts":attempts,"avg":avg,"pings":pings}

try:
    with open(INPUT_PATH,"r",encoding="utf-8") as f: lines=[ln.strip() for ln in f if ln.strip()]
except: lines=[]

raw_proxies=[]
for line in lines:
    try:
        if line.startswith("vless://"):
            parsed=urlparse(line)
            uid=parsed.username or ""
            host=parsed.hostname or ""
            port=parsed.port or 443
            if not (uid and host and port): continue
            raw_proxies.append({"type":"vless","server":host,"port":int(port),"uuid":uid,"network":"tcp"})
        elif line.startswith("vmess://"):
            payload=line[8:]
            try: info=json.loads(base64.b64decode(b64fix(payload)).decode(errors="ignore"))
            except: continue
            host=info.get("add",""); port=safe_int(info.get("port",0)); uid=info.get("id","")
            if not (host and port and uid): continue
            raw_proxies.append({"type":"vmess","server":host,"port":port,"uuid":uid,"network":"tcp"})
        elif line.startswith("trojan://"):
            parsed=urlparse(line)
            pwd=parsed.username or ""; host=parsed.hostname or ""; port=parsed.port or 443
            if not (pwd and host and port): continue
            raw_proxies.append({"type":"trojan","server":host,"port":int(port),"password":pwd,"network":"tcp","tls":True})
        elif line.startswith("ss://"):
            try:
                after=line[5:]
                if "@" in after and ":" in after.split("@",1)[0]:
                    cred, rest=after.split("@",1)
                    method,password=cred.split(":",1)
                    host,port=rest.rsplit(":",1)
                else:
                    if "@" not in after: continue
                    b64cred, rest=after.split("@",1)
                    method,password=base64.urlsafe_b64decode(b64fix(b64cred)).decode().split(":",1)
                    host,port=rest.rsplit(":",1)
                raw_proxies.append({"type":"ss","server":host.strip(),"port":safe_int(port,0),"cipher":method.strip(),"password":password.strip(),"network":"tcp"})
            except: continue
    except: continue

# ---------- dedupe + assign names ----------
dedup={}
final_list=[]
for rp in raw_proxies:
    if not rp.get("server") or not rp.get("port"): continue
    key=canonical_key(rp)
    if key in dedup:
        ex=dedup[key]
        for k,v in rp.items():
            if not ex.get(k) and v: ex[k]=v
        continue
    base=f"{rp.get('type','proxy')}-{rp.get('server')}-{tail(str(rp.get('port')))}"
    name=uniq_name(base); rp["name"]=name
    dedup[key]=rp; final_list.append(rp)

# ---------- health ----------
def health_smart(p):
    host=p.get("server"); port=p.get("port")
    out=dict(p); out["ping"]=None; out["status"]="ok"; out["success"]=3; out["avg_ping"]=0
    try:
        summary=multi_ping_summary(host,port,attempts=1,timeout=2.0)
        if summary["avg"]: out["ping"]=summary["avg"]
        out["success"]=summary["success"]
        out["avg_ping"]=summary["avg"]
        if summary["success"]==0: out["status"]="dead"
    except: pass
    return out

results=[]
if final_list:
    with ThreadPoolExecutor(max_workers=min(60,len(final_list))) as ex:
        futs={ex.submit(health_smart,p):p for p in final_list}
        for fut in as_completed(futs):
            try: results.append(fut.result())
            except: pass

final_proxies=[p for p in results] if results else final_list

proxy_names=[p["name"] for p in final_proxies]

proxy_groups=[
    {"name":"Fastest","type":"select","proxies":[p["name"] for p in sorted(final_proxies, key=lambda x:x.get("ping") or 0)]},
    {"name":"Stable","type":"select","proxies":[p["name"] for p in sorted(final_proxies, key=lambda x:(-(x.get("success") or 0), x.get("ping") or 0))]},
    {"name":"SmartSwitch","type":"select","proxies":[p["name"] for p in final_proxies]},
    {"name":"Selector","type":"select","proxies":["SmartSwitch","Stable","Fastest","DIRECT"]+proxy_names},
    {"name":"Backup","type":"fallback","url":"https://www.gstatic.com/generate_204","interval":30,"tolerance":120,"proxies":["DIRECT"]+proxy_names},
    {"name":"Direct","type":"select","proxies":["DIRECT"]},
    {"name":"Block","type":"select","proxies":["REJECT","DIRECT"]}
]

config={"proxies":final_proxies,"proxy-groups":proxy_groups,"rules":["MATCH,Selector"]}

with open(OUT_PATH,"w",encoding="utf-8") as f: yaml.safe_dump(config,f,allow_unicode=True,sort_keys=False)
with open(INPUT_PATH,"w",encoding="utf-8") as f: f.write("")
print(f"[✅] Saved {len(final_proxies)} proxies to {OUT_PATH}")