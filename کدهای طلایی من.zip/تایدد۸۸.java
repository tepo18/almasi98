import os
import re
import json
import yaml
import base64
import subprocess
from urllib.parse import unquote, parse_qs
from rich import print

protocols = ["vless://", "vmess://", "trojan://", "ss://"]

def extract_host(config: str):
    match = re.search(r"@([^:/?#]+)", config)
    return match.group(1) if match else None

def ping_host(host: str):
    try:
        output = subprocess.check_output(
            ["ping", "-c", "3", "-W", "1", host],
            stderr=subprocess.DEVNULL
        ).decode(errors="ignore")
        match = re.search(r"rtt min/avg/max/(?:mdev|stddev) = [\d.]+/([\d.]+)", output)
        return float(match.group(1)) if match else None
    except Exception:
        return None

def classify_ping(ping: float):
    if ping is None:
        return "bad", "[bold red][BAD][/bold red]"
    elif ping < 150:
        return "good", "[bold green][GOOD][/bold green]"
    elif ping < 300:
        return "warn", "[bold yellow][WARN][/bold yellow]"
    else:
        return "bad", "[bold red][BAD][/bold red]"

def parse_link(link: str):
    link = link.strip()
    if not link.startswith("vless://"):
        return None, None

    try:
        main_part = link.split("://", 1)[1]
        remark = ""
        if "#" in main_part:
            main_part, remark = main_part.split("#", 1)

        query = {}
        if "?" in main_part:
            addr_port, params = main_part.split("?", 1)
            query = parse_qs(params)
        else:
            addr_port = main_part

        user, host_port = ("", addr_port)
        if '@' in addr_port:
            user, host_port = addr_port.split("@", 1)

        if ':' in host_port:
            address, port = host_port.split(":", 1)
        else:
            address, port = host_port, "443"

        parsed = {
            "protocol": "vless",
            "address": address,
            "port": int(port) if port.isdigit() else 443,
            "id": user,
            "params": {k: v[0] for k, v in query.items()},
            "remark": unquote(remark)
        }
        return "vless", parsed
    except Exception:
        return None, None

def build_fragment_list(configs: list):
    fragments = []
    for i, cfg in enumerate(configs, start=1):
        params = cfg.get("params", {})
        network = params.get("type", "ws")
        security = params.get("security", "tls")

        server_name = params.get("sni") or params.get("host") or cfg["address"]
        alpn_raw = params.get("alpn", "")
        alpn = [p for p in (alpn_raw.split(",") if alpn_raw else []) if p] or ["http/1.1"]

        stream_settings = {
            "network": network,
            "security": security,
            "sockopt": {"dialerProxy": "fragment"}
        }

        if security == "tls":
            stream_settings["tlsSettings"] = {
                "serverName": server_name,
                "fingerprint": params.get("fp", "chrome"),
                "alpn": alpn
            }

        if network == "ws":
            stream_settings["wsSettings"] = {
                "path": params.get("path", "/"),
                "headers": {"Host": params.get("host") or server_name}
            }

        outbound_proxy = {
            "tag": "proxy",
            "protocol": "vless",
            "settings": {
                "vnext": [{
                    "address": cfg["address"],
                    "port": cfg["port"],
                    "users": [{
                        "id": cfg["id"],
                        "encryption": params.get("encryption", "none"),
                        "flow": params.get("flow", "")
                    }]
                }]
            },
            "streamSettings": stream_settings
        }

        outbound_fragment = {
            "tag": "fragment",
            "protocol": "freedom",
            "settings": {
                "fragment": {
                    "packets": "tlshello",
                    "length": "100-200",
                    "interval": "1-1"
                },
                "domainStrategy": "UseIPv4v6"
            }
        }

        inbound_socks = {
            "port": 10808,
            "protocol": "socks",
            "settings": {"auth": "noauth", "udp": True, "userLevel": 8},
            "sniffing": {"destOverride": ["http", "tls"], "enabled": True, "routeOnly": True},
            "tag": "socks-in"
        }

        inbound_dns = {
            "port": 10853,
            "protocol": "dokodemo-door",
            "settings": {
                "address": "1.1.1.1",
                "network": "tcp,udp",
                "port": 53
            },
            "tag": "dns-in"
        }

        routing = {
            "domainStrategy": "IPIfNonMatch",
            "rules": [
                {
                    "inboundTag": ["dns-in"],
                    "outboundTag": "dns-out",
                    "type": "field"
                },
                {
                    "network": "tcp",
                    "outboundTag": "proxy",
                    "type": "field"
                }
            ]
        }

        fragment = {
            "remarks": cfg.get("remark") or f"💦 {i} - VLESS",
            "log": {"loglevel": "warning"},
            "inbounds": [inbound_socks, inbound_dns],
            "outbounds": [outbound_proxy, outbound_fragment],
            "routing": routing
        }

        fragments.append(fragment)

    return fragments

def save_output(configs: list):
    save_path = "/storage/emulated/0/Download/Akbar98"
    os.makedirs(save_path, exist_ok=True)

    while True:
        print("\n[bold cyan]📤 Choose output format:[/bold cyan]")
        print("1. Fragmented JSON")
        print("2. Simple JSON")
        print("3. TXT Summary")
        print("4. YAML File")
        print("5. Base64 Fragment JSON")
        print("6. Raw JSON Line")
        print("0. Exit")

        choice = input("👉 Enter option (0-6): ").strip()
        if choice == "0":
            break

        file_name = input("📁 Enter filename (without extension): ").strip()
        if not file_name:
            print("[red]❌ Filename cannot be empty[/red]")
            continue

        full_path = ""
        try:
            if choice == "1":
                output_data = build_fragment_list(configs)
                full_path = os.path.join(save_path, file_name + ".json")
                with open(full_path, "w", encoding="utf-8") as f:
                    json.dump(output_data, f, indent=2, ensure_ascii=False)

            elif choice == "2":
                full_path = os.path.join(save_path, file_name + ".json")
                with open(full_path, "w", encoding="utf-8") as f:
                    json.dump(configs, f, indent=2, ensure_ascii=False)

            elif choice == "3":
                lines = [
                    f"{i}. vless://{cfg['id']}@{cfg['address']}:{cfg['port']}  remark: {cfg.get('remark','')}"
                    for i, cfg in enumerate(configs, 1)
                ]
                full_path = os.path.join(save_path, file_name + ".txt")
                with open(full_path, "w", encoding="utf-8") as f:
                    f.write("\n".join(lines))

            elif choice == "4":
                full_path = os.path.join(save_path, file_name + ".yaml")
                with open(full_path, "w", encoding="utf-8") as f:
                    yaml.dump(configs, f, allow_unicode=True)

            elif choice == "5":
                b64 = base64.b64encode(json.dumps(build_fragment_list(configs)).encode()).decode()
                full_path = os.path.join(save_path, file_name + ".b64")
                with open(full_path, "w", encoding="utf-8") as f:
                    f.write(b64)

            elif choice == "6":
                compact = json.dumps(configs, separators=(",", ":"), ensure_ascii=False)
                full_path = os.path.join(save_path, file_name + ".json")
                with open(full_path, "w", encoding="utf-8") as f:
                    f.write(compact)

            else:
                print("[red]❌ Invalid choice[/red]")
                continue

            print(f"[bold green]✅ Saved at: {full_path}[/bold green]")
            print("[cyan]Choose next option or 0 to exit[/cyan]")
        except Exception as e:
            print(f"[bold red]❌ Error: {e}[/bold red]")

def main():
    print("[cyan]Paste your configs (Ctrl+D to finish):[/cyan]")
    lines = []
    while True:
        try:
            line = input()
            if line.strip():
                lines.append(line.strip())
        except EOFError:
            break

    good_configs = []
    for line in lines:
        if not any(line.startswith(p) for p in protocols):
            continue

        host = extract_host(line)
        if not host:
            print(f"[bold red][INVALID][/bold red] {line}")
            continue

        ping = ping_host(host)
        status, label = classify_ping(ping)
        print(f"{label} {host} - {ping if ping else 'NO REPLY'}ms")

        if status == "good":
            proto, parsed = parse_link(line)
            if proto and parsed:
                good_configs.append(parsed)

    if not good_configs:
        print("[red]❌ No good configs found[/red]")
        return

    save_output(good_configs)

if __name__ == "__main__":
    main()
