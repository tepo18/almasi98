#!/bin/bash

# Colors
CYAN="\033[36m"
GREEN="\033[32m"
YELLOW="\033[33m"
RESET="\033[0m"

BASE_PATH="$HOME"
DOWNLOAD_DIR="/sdcard/Download/Akbar98"

# Set git username if not set
if [ -z "$(git config --global user.name)" ]; then
  echo -ne "${CYAN}Enter your Git user.name: ${RESET}"
  read -r GIT_USER_NAME
  git config --global user.name "$GIT_USER_NAME"
fi

# Set git email if not set
if [ -z "$(git config --global user.email)" ]; then
  echo -ne "${CYAN}Enter your Git user.email: ${RESET}"
  read -r GIT_USER_EMAIL
  git config --global user.email "$GIT_USER_EMAIL"
fi

# Repo selection
echo -e "${CYAN}Have you already cloned the repo?${RESET}"
echo "1) No, I want to clone a new repo"
echo "2) Yes, I already have it"
echo -ne "${CYAN}Enter choice (1 or 2): ${RESET}"
read -r CLONE_CHOICE

if [ "$CLONE_CHOICE" == "1" ]; then
  echo -ne "${CYAN}Enter the GitHub repo name (e.g. my-repo): ${RESET}"
  read -r REPO_NAME
  REPO_PATH="$BASE_PATH/$REPO_NAME"

  if [ -d "$REPO_PATH" ]; then
    echo -e "${YELLOW}Folder already exists!${RESET}"
  else
    echo -e "${GREEN}Cloning repo...${RESET}"
    git clone "https://github.com/tepo18/$REPO_NAME.git" "$REPO_PATH" || {
      echo -e "${YELLOW}Failed to clone repo. Exiting.${RESET}"
      exit 1
    }
  fi

elif [ "$CLONE_CHOICE" == "2" ]; then
  echo -ne "${CYAN}Enter your repo folder name: ${RESET}"
  read -r REPO_NAME
  REPO_PATH="$BASE_PATH/$REPO_NAME"

  if [ ! -d "$REPO_PATH" ]; then
    echo -e "${YELLOW}Folder not found! Exiting.${RESET}"
    exit 1
  fi
else
  echo -e "${YELLOW}Invalid choice. Exiting.${RESET}"
  exit 1
fi

cd "$REPO_PATH" || { echo -e "${YELLOW}Cannot enter repo folder. Exiting.${RESET}"; exit 1; }

while true; do
  echo -e "\n${CYAN}Select an option:${RESET}"
  echo "1) Create new file"
  echo "2) Edit existing file"
  echo "3) Delete a file"
  echo "4) Commit changes"
  echo "5) Push to GitHub"
  echo "6) Copy from download folder to repo"
  echo "7) Exit"
  echo -ne "${CYAN}Choice: ${RESET}"
  read -r CHOICE

  case $CHOICE in
    1)
      echo -ne "${CYAN}Enter new filename: ${RESET}"
      read -r NEWFILE
      [ -e "$NEWFILE" ] && echo -e "${YELLOW}File already exists.${RESET}" || { touch "$NEWFILE"; echo -e "${GREEN}File created.${RESET}"; }
      ;;
    2)
      echo -ne "${CYAN}Enter filename to edit: ${RESET}"
      read -r EDITFILE
      [ -e "$EDITFILE" ] && nano "$EDITFILE" || echo -e "${YELLOW}File does not exist.${RESET}"
      ;;
    3)
      echo -ne "${CYAN}Enter filename to delete: ${RESET}"
      read -r DELFILE
      [ -e "$DELFILE" ] && { rm -i "$DELFILE"; echo -e "${GREEN}File deleted.${RESET}"; } || echo -e "${YELLOW}File does not exist.${RESET}"
      ;;
    4)
      git status
      echo -ne "${CYAN}Enter commit message (leave empty for default): ${RESET}"
      read -r MSG
      git add .
      [ -z "$MSG" ] && MSG="auto update from script"
      git commit -m "$MSG" && echo -e "${GREEN}Changes committed.${RESET}" || echo -e "${YELLOW}Nothing to commit.${RESET}"
      ;;
    5)
      echo -ne "${CYAN}Push changes to GitHub? (yes/no): ${RESET}"
      read -r PUSH_ANSWER
      if [ "$PUSH_ANSWER" == "yes" ]; then
        git push || {
          echo -e "${YELLOW}Push failed. Trying to pull first...${RESET}"
          git pull --rebase && git push || echo -e "${YELLOW}Push failed again. Resolve manually.${RESET}"
        }
      fi
      ;;
    6)
      echo -ne "${CYAN}Enter source filename in $DOWNLOAD_DIR: ${RESET}"
      read -r SRCFILE
      SRC_PATH="$DOWNLOAD_DIR/$SRCFILE"
      if [ -f "$SRC_PATH" ]; then
        echo -ne "${CYAN}Enter target filename in repo: ${RESET}"
        read -r TARGETFILE
        cp "$SRC_PATH" "$TARGETFILE"
        echo -e "${GREEN}File copied successfully.${RESET}"
      else
        echo -e "${YELLOW}Source file not found.${RESET}"
      fi
      ;;
    7)
      echo "Exiting."
      exit 0
      ;;
    *)
      echo -e "${YELLOW}Invalid choice!${RESET}"
      ;;
  esac
done
