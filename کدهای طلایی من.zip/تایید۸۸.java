import os
import re
import subprocess
import json
import urllib.parse
from urllib.parse import quote
from rich import print
from rich.table import Table
from rich.prompt import Prompt

protocols = ["vmess://", "vless://", "trojan://", "ss://"]

# ==================== توابع اصلی ====================
def extract_host(config):
    match = re.search(r"@([^:/?#]+)", config)
    return match.group(1) if match else None


def ping_host(host):
    try:
        output = subprocess.check_output(
            ["ping", "-c", "3", "-W", "1", host],
            stderr=subprocess.DEVNULL
        ).decode()
        match = re.search(r"rtt min/avg/max/mdev = [\d.]+/([\d.]+)", output)
        return float(match.group(1)) if match else None
    except Exception:
        return None


def classify_ping(ping):
    if ping is None:
        return "bad", "[bold red][BAD][/bold red]"
    elif ping < 150:
        return "good", "[bold green][GOOD][/bold green]"
    elif ping < 300:
        return "warn", "[bold yellow][WARN][/bold yellow]"
    else:
        return "bad", "[bold red][BAD][/bold red]"


def combine_configs(*lists):
    combined = []
    length = min(len(lst) for lst in lists)
    for i in range(length):
        combined.append("+".join(lst[i] for lst in lists))
    return combined


def save_to_file(configs, folder, filename):
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, filename)
    with open(path, "w", encoding="utf-8") as f:
        for conf in configs:
            f.write(conf + "\n")
    return path


# ==================== خروجی Fragment و JSON ====================
def parse_link(link):
    link = link.strip()
    if not link.startswith("vless://"):
        return None, None

    try:
        main_part = link.split("://", 1)[1]
        remark = ""
        if "#" in main_part:
            main_part, remark = main_part.split("#", 1)
        if "?" in main_part:
            addr_port, params = main_part.split("?", 1)
            query = urllib.parse.parse_qs(params)
        else:
            addr_port = main_part
            query = {}

        if "@" in addr_port:
            user, host_port = addr_port.split("@", 1)
        else:
            user = ""
            host_port = addr_port

        if ":" in host_port:
            address, port = host_port.split(":", 1)
        else:
            address = host_port
            port = "443"

        return "vless", {
            "protocol": "vless",
            "address": address,
            "port": int(port) if port.isdigit() else 443,
            "id": user,
            "params": {k: v[0] for k, v in query.items()},
            "remark": urllib.parse.unquote(remark)
        }
    except:
        return None, None


def build_fragment_list(configs):
    fragments = []
    for i, cfg in enumerate(configs):
        outbound = {
            "tag": "proxy",
            "protocol": "vless",
            "settings": {
                "vnext": [{
                    "address": cfg["address"],
                    "port": cfg["port"],
                    "users": [{
                        "id": cfg["id"],
                        "encryption": cfg["params"].get("encryption", "none"),
                        "flow": cfg["params"].get("flow", "")
                    }]
                }]
            },
            "streamSettings": {
                "network": cfg["params"].get("type", "ws"),
                "security": cfg["params"].get("security", "tls"),
                "sockopt": {"dialerProxy": "fragment"},
                "tlsSettings": {
                    "serverName": cfg["params"].get("sni", cfg["params"].get("host", cfg["address"])),
                    "fingerprint": cfg["params"].get("fp", "chrome"),
                    "alpn": cfg["params"].get("alpn", "").split(",") if "alpn" in cfg["params"] else ["http/1.1"]
                },
                "wsSettings": {
                    "path": cfg["params"].get("path", "/"),
                    "headers": {
                        "Host": cfg["params"].get("host", cfg["address"])
                    }
                }
            }
        }

        fragment = {
            "remarks": cfg["remark"] or f"Config {i+1}",
            "log": {"loglevel": "warning"},
            "dns": {},
            "inbounds": [],
            "outbounds": [outbound],
            "routing": {}
        }
        fragments.append(fragment)
    return fragments


# ==================== کد اصلی ====================
def main():
    print("[bold cyan]Enter your configs line by line. Press Enter on empty line to ignore. Ctrl+D to finish input.[/bold cyan]")

    lines = []
    while True:
        try:
            line = input()
            if line.strip() == "":
                continue
            lines.append(line.strip())
        except EOFError:
            break

    valid_configs = [c for c in lines if any(c.startswith(p) for p in protocols)]
    if not valid_configs:
        print("[bold red]No valid configs entered.[/bold red]")
        return

    green_configs, yellow_configs, red_configs = [], [], []
    ping_results = {}

    for conf in valid_configs:
        host = extract_host(conf)
        if not host:
            print(f"[bold red][INVALID HOST][/bold red] {conf}")
            continue
        ping = ping_host(host)
        status, label = classify_ping(ping)
        ping_results[conf] = (ping, status)
        print(f"{label} {host} - {str(ping) + ' ms' if ping is not None else 'NO REPLY'}")

        if status == "good":
            green_configs.append(conf)
        elif status == "warn":
            yellow_configs.append(conf)
        else:
            red_configs.append(conf)

    folder = "/storage/emulated/0/Download/Akbar98"

    while True:
        print("\n[bold cyan]Select output option:[/bold cyan]")
        print("1) Green configs")
        print("2) Green + Yellow configs")
        print("3) All configs")
        print("4) Fragmented Config (V2Ray)")
        print("5) Raw JSON")
        print("0) Exit")

        choice = Prompt.ask("Enter choice number", choices=[str(i) for i in range(0, 6)])

        if choice == "0":
            print("[bold green]Exiting...[/bold green]")
            break

        output_configs = []

        if choice == "1":
            output_configs = green_configs
        elif choice == "2":
            output_configs = green_configs + yellow_configs
        elif choice == "3":
            output_configs = valid_configs
        elif choice == "4":
            parsed_configs = []
            for conf in valid_configs:
                proto, parsed = parse_link(conf)
                if parsed:
                    parsed_configs.append(parsed)
            file_name = Prompt.ask("Enter filename for Fragment (without extension)", default="fragment")
            save_path = os.path.join(folder, file_name + ".json")
            with open(save_path, "w", encoding="utf-8") as f:
                json.dump(build_fragment_list(parsed_configs), f, indent=2, ensure_ascii=False)
            print(f"[green]✅ Fragment saved to {save_path}[/green]")
            continue
        elif choice == "5":
            parsed_configs = []
            for conf in valid_configs:
                proto, parsed = parse_link(conf)
                if parsed:
                    parsed_configs.append(parsed)
            file_name = Prompt.ask("Enter filename for JSON (without extension)", default="raw_json")
            save_path = os.path.join(folder, file_name + ".json")
            with open(save_path, "w", encoding="utf-8") as f:
                json.dump(parsed_configs, f, indent=2, ensure_ascii=False)
            print(f"[green]✅ JSON saved to {save_path}[/green]")
            continue

        if not output_configs:
            print("[red]No configs to output.[/red]")
            continue

        file_name = Prompt.ask("Enter filename (without extension)", default="output")
        save_to_file(output_configs, folder, file_name + ".txt")
        print(f"[green]✅ Saved to {folder}/{file_name}.txt[/green]")


if __name__ == "__main__":
    main()

